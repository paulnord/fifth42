"""Reproduce the finite computations for 8, 9 and 42 using only Python 3.8+."""

from functools import lru_cache
from itertools import combinations_with_replacement, product


def check(actual, expected, description):
    if actual != expected:
        raise ValueError(f"{description}: found {actual}, expected {expected}")


def multiply(left, right, p):
    """Multiply in F_p[T]/(1+T+T²+T³+T⁴), using the power basis."""
    coefficients = [0] * 7
    for i, a in enumerate(left):
        for j, b in enumerate(right):
            coefficients[i + j] += a * b
    for degree in range(6, 3, -1):
        for j in range(degree - 4, degree):
            coefficients[j] -= coefficients[degree]
    return tuple(x % p for x in coefficients[:4])


def power(base, exponent, p):
    result = (1, 0, 0, 0)
    while exponent:
        if exponent % 2:
            result = multiply(result, base, p)
        base = multiply(base, base, p)
        exponent //= 2
    return result


@lru_cache(maxsize=None)
def character(p, u, v):
    """Discrete logarithm of (u+Tv)^((p^4−1)/5) to the global root T."""
    value = power((u % p, v % p, 0, 0), (p**4 - 1) // 5, p)
    roots = [power((0, 1, 0, 0), k, p) for k in range(5)]
    return roots.index(value)


def verify_labels_and_pairs():
    labels = {8: (0, 1, 2), 9: (1, 1, 2), 42: (0, 3, 4)}
    for target, expected in labels.items():
        found = [row for row in combinations_with_replacement(range(5), 3)
                 if (sum(x**5 for x in row) - target) % 25 == 0]
        check(found, [expected], f"labels for {target}")
        print(f"Target {target}: base residues modulo 5 are {expected}, up to order.")

    for p, finite, infinity in [(2, [0, 4], 3), (3, [0, 3, 3], 1),
                                (7, [0, 0, 1, 2, 4, 3, 0], 0)]:
        check([character(p, 1, r) for r in range(p)], finite, f"e_{p}(1,r)")
        check(character(p, 0, 1), infinity, f"e_{p}(0,1)")
        print(f"p={p}: e_p(1,r) = {finite}; e_p(0,1) = {infinity}.")

    for target, p, pair, expected in [(8, 2, (2, 1), [0, 3, 4]),
                                      (9, 3, (1, 2), [0, 1, 3, 3])]:
        u, v = pair
        h = v * pow(u + v, -1, 5) % 5
        required = h * character(p, 0, 1) % 5
        lines = [(1, 0), (0, 1)] + [(1, r) for r in range(1, p)]
        possible = [character(p, a, b) for a, b in lines]
        check(possible, expected, f"one-pair table for {target}")
        check(required, {8: 1, 9: 4}[target], f"required exponent for {target}")
        check(required in possible, False, f"one-pair exclusion for {target}")
        print(f"Target {target}: required exponent {required}; available {possible}.")


def verify_projective_rows():
    expected = {
        2: {4: ["011", "101", "110"]},
        3: {3: ["012", "102", "111", "120"]},
        7: {0: ["016", "106", "113", "131", "155", "160"], 2: ["142"], 3: ["124"]},
    }
    possibilities = []
    for p, table in expected.items():
        rows = {}
        for a, b, c in product(range(p), repeat=3):
            if next((x for x in (a, b, c) if x), 0) != 1:
                continue
            if (a**5 + b**5 + c**5) % p:
                continue
            combined = (-character(p, a, c) + character(p, b, c) + character(p, a, b)) % 5
            rows.setdefault(combined, []).append(f"{a}{b}{c}")
        check(rows, table, f"projective rows for p={p}")
        possibilities.append(sorted(rows))
        for exponent, triples in sorted(rows.items()):
            print(f"p={p}, E_p={exponent}: {', '.join(triples)}")
    totals = sorted({sum(terms) % 5 for terms in product(*possibilities)})
    correction = sum(character(p, 0, 1) for p in expected) % 5
    oriented_pairs = [(3, 0), (4, 0), (3, 4)]
    required = [correction * v * pow(u + v, -1, 5) % 5 for u, v in oriented_pairs]
    check(required, [0, 0, 3], "required exponents for 42")
    combined = (-required[0] + required[1] + required[2]) % 5
    check(totals, [0, 2, 4], "combined totals for 42")
    check(combined in totals, False, "three-pair exclusion for 42")
    print(f"Target 42: required total {combined}; available {totals}.")


def verify_local_solutions():
    pairs = {25: (-1, -2), 11: (-1, -1), 31: (-3, -5), 41: (0, 1),
             61: (-2, -4), 71: (1, -3), 101: (1, 3)}
    for modulus, (u, v) in pairs.items():
        p = 5 if modulus == 25 else modulus
        check((u**5 + v**5 - 42) % modulus, 0, f"binary witness modulo {modulus}")
        check(u % p != 0 or v % p != 0, True, f"unit coordinate modulo {p}")
    print(f"Binary witnesses for 42 verified modulo {', '.join(map(str, sorted(pairs)))}.")
    for modulus in (11, 25, 31, 41, 61, 71, 101, 131, 151):
        p = 5 if modulus == 25 else modulus
        powers = {pow(x, 5, modulus) for x in range(modulus)}
        sums = {(a + b + c) % modulus for a, b, c in product(powers, repeat=3)
                if a % p or b % p or c % p}
        missing = set(range(modulus)) - sums
        check(missing, {4, 5, 6, 7} if modulus == 11 else set(), f"ternary sums mod {modulus}")
    print("Finite ternary local checks passed, with only 4, 5, 6, 7 missing modulo 11.")


if __name__ == "__main__":
    verify_labels_and_pairs()
    verify_projective_rows()
    verify_local_solutions()
