# A quintic reciprocity obstruction for sums of three fifth powers

The [four-page paper](fifth42.pdf) treats 8, 9 and 42. All three admit solutions modulo every positive integer. The proof rules out an integer representation and shows that any rational representation must have reduced common denominator divisible by 5. The [survey](supplement/README.md) and its [1,000-target catalogue](supplement/targets-1-1000.csv) accompany the article.

The [LaTeX source](fifth42.tex) contains the bibliography and table. Build it from this directory with two passes of pdfLaTeX.

```sh
pdflatex -halt-on-error fifth42.tex
pdflatex -halt-on-error fifth42.tex
```

Run the checks for the article with Python 3.8 or later. The program uses only the standard library.

```sh
python3 verification/verify_article.py
```

The [Lean file](verification/Fifth42.lean) checks the finite contradiction for the integer target 42 conditional on the pairwise reciprocity statement. Lemma 3 gives the mathematical deduction from Eisenstein reciprocity. To replay the certificate with Elan and the supplied Lean 4.36.0 toolchain pin, run the following from this directory.

```sh
(cd verification && lean Fifth42.lean)
```

To reproduce the wider catalogue and its height-10,000 witness search, use the [supplement’s instructions](supplement/README.md#reproduction).
