# The reciprocity calculation for the catalogue

Write $n=md^5$ with $m$ fifth-power-free and $d>0$. For $n\le1000$ we have $5\nmid d$. Dividing a hypothetical integral representation by $d$ gives a rational representation of $m$ with denominator prime to 5. Clearing denominators in lowest terms gives
$$
 A^5+B^5+C^5=mD^5,\qquad \gcd(A,B,C,D)=1,\qquad 5\nmid D.
$$
The case $m=1$ has a witness. Suppose $m>1$. No two coordinates can sum to zero, since the remaining coordinate would then give a rational fifth root of $m$.

Let $F=\mathbf Q(\zeta)$ for a primitive fifth root of unity $\zeta$. For each ordered pair of positions $(A,B),(A,C),(B,C)$ write $L=u+\zeta v$ and let $w$ denote the remaining coordinate. Use the local fifth Hilbert symbol convention in which $(\varpi,U)$ at a tame prime with uniformizer $\varpi$ and unit $U$ reduces to the character of $U$. Take every discrete logarithm with respect to the same global $\zeta$, reduced at the relevant prime. By Hilbert reciprocity, the sum of the local exponents for $(m,L)$ over all places of $F$ is zero modulo 5. [Venjakob, §4.1](https://www.mathi.uni-heidelberg.de/~otmar/papervenjakob/explizitreciprocityLaw.pdf)

The product of the five factors $u+\zeta^jv$, for $0\le j<5$, is $mD^5-w^5$. This is the norm of $D\sqrt[5]m-w$ in the degree-five Kummer extension of $F$ obtained by adjoining $\sqrt[5]m$. The pairing of $m$ with this norm is trivial at every place, including where the extension splits. This identity determines the symbol of one vanishing factor from the four that remain units.

## Contributions away from 5

For a prime ideal $P$ away from $5m$, the Hilbert symbol is trivial when $L$ is a unit. If $P\mid L$, then $u^5+v^5$ vanishes modulo $P$. When $P\nmid D$, the identity $m\equiv(w/D)^5\pmod P$ and Hensel lifting make $m$ a local fifth power. When $P\mid D$, primitivity forces $P\mid w$ and $u,v$ to be units. The four other factors are then units, so each pairs trivially with $m$. The norm identity gives the same conclusion for $L$. The infinite places of $F$ are complex and contribute zero.

Now take $p^e\parallel m$ with $p\ne5$. Some coordinate is a unit modulo $p$. Otherwise, if $p\mid D$ this contradicts primitivity, and if $p\nmid D$ the equation gives $p^5\mid m$. Hence the triple modulo $p$ determines a projective solution to
$$A^5+B^5+C^5=0\quad\text{over }\mathbf F_p.$$
At a prime $P\mid p$ where $L$ is a unit, the local exponent is $e$ times the logarithm of $L^{(N(P)-1)/5}$ modulo $P$. For $p\equiv2,3\pmod5$ use the field of $p^4$ elements defined by $\Phi_5$. For $p\equiv4\pmod5$ use both quadratic factors of $\Phi_5$, taking logarithms separately in the two fields. In both cases $\zeta\notin\mathbf F_p$, so a pair can only vanish if both its coordinates do, which would force the third coordinate to vanish as well. [Nonsplit computation](reciprocity/classify.py)

When $p\equiv1\pmod5$, evaluate at each of the four primitive fifth roots in $\mathbf F_p$. If $u+\zeta v\equiv0$ at one root, both coordinates are units and the other four factors have product $5u^4$ modulo $P$ by the derivative of $X^5+v^5$. The norm identity gives the same Hilbert symbol for $L$ as for the unit $(5u^4)^{-1}$. This accounts for singular factors even if $p\mid D$. The global generator fixes the interpretation of the logarithm at each of the four roots. [Split-prime computation](survey/catalogue.py)

Multiplying the triple by a single element of $\mathbf F_p^\times$ preserves the aggregate exponent at $p$. For $p\not\equiv1\pmod5$ every rational residue unit is a fifth power. At a split prime a rational scalar contributes exponents with sum zero, as its characters over all four primes above $p$ have Galois-invariant product in $\mu_5$. At a vanishing factor the replacement unit scales by the inverse fourth power of the scalar, which has the same fifth-power character as the scalar. Thus one may normalize the first nonzero coordinate to one. The algorithm stores the three exponents together for each projective point.

## The contribution at 5

Use $A/D,B/D,C/D$ as 5-adic integers. Because the symbol $(m,D)$ at the unique prime above 5 is Galois-invariant, it is trivial. Replacing numerator coordinates by these rational coordinates therefore preserves the exponent at 5. We compute the negative of this exponent, which must equal the sum of exponents away from 5.

* For $5\nmid m$, a value $m\equiv\pm1,\pm7\pmod{25}$ is a fifth power in $\mathbf Z_5^\times$, by lifting a unit fifth power modulo 25. In these classes all three required exponents are zero. In each remaining unit class, enumerating the possible fifth powers $0,\pm1,\pm7$ modulo 25 shows that the sum of the two bases in each pair is a unit. For $h=v/(u+v)\bmod5$, the required exponent is $h\log_\zeta(\zeta/(m))_5$, where the symbol in this expression is the power residue symbol with ideal denominator $(m)$. This follows by the primary normalization in Eisenstein reciprocity, applied to a calibration element coprime to $m$. [Calibration derivation](wild/method.md)
* For $5\parallel m$, enumerate solutions modulo 125 using base residues modulo 25. For each pair, evaluate the Hilbert symbol by matching it up to a local fifth power with a global element $1+k(\zeta-1)$. Compute the other local symbols of this element and apply the product formula. [Calibration and worked example for 10](wild/method.md)
* For $25\mid m$, the primitive base patterns contain opposite units modulo 5. For their pair use a calibration by $k+\zeta$, with $k$ determined modulo 125. The equation modulo 625 determines all joint rows from base residues modulo 125. [Opposite-unit calculation](wild/method.md#opposite-units-at-5)

For each $p\mid m$, $p\ne5$, the code forms the set of allowed three-component exponent vectors. It takes their sums in $(\mathbf Z/5\mathbf Z)^3$ and intersects the resulting set with the required vectors at 5. An empty intersection proves that the assumed representation is impossible. A surviving vector satisfies the tested necessary conditions. [Catalogue implementation](survey/catalogue.py)

## Computational controls

The two nonsplit implementations use different projective normalizations and different polynomial arithmetic. The split-prime checks compute symbols directly using lifted primitive fifth roots, valuations, and unit residues for 666 integral controls (236 with a vanishing factor) and five rational controls with denominators divisible by the tested prime. At 5, a direct global calibration and a factored formula agree at 25 residues for each of 1,000 targets. For the opposite-unit case a second representative reproduces all 1,000 calibration values. A further 76 attained control triples give the predicted exponents. All 44 integer witnesses in the catalogue pass the reciprocity test. [Nonsplit cross-check](reciprocity/crosscheck.py) · [Split-prime results](survey/tests/split_prime.json) · [Calculations at 5](wild/wild.py) · [Opposite-unit controls](wild/check_opposite.py)
