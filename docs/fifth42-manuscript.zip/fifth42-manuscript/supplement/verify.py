"""Replay the supplement and compare regenerated data with the supplied tables."""
import argparse
import csv
import json
import subprocess
import sys
import tempfile
from collections import Counter
from itertools import combinations_with_replacement
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def run_python(script, *args):
    return subprocess.check_output(
        [sys.executable, "-B", str(ROOT / script), *map(str, args)], text=True
    )


def assert_match(generated, published):
    if generated.read_bytes() != (ROOT / published).read_bytes():
        raise ValueError(f"The regenerated table differs from {published}")


def verify_catalogue():
    with (ROOT / "targets-1-1000.csv").open(newline="") as stream:
        rows = list(csv.DictReader(stream))
    assert [int(row["target"]) for row in rows] == list(range(1, 1001))
    counts = Counter(row["classification"] for row in rows)
    assert counts == {"represented": 44, "mod 11": 364,
                      "reciprocity": 108, "undecided": 484}

    excluded = set()
    cores = set()
    represented = {}
    for row in rows:
        n, core, scale = (int(row[name]) for name in
                          ("target", "fifth_power_free_part", "scale"))
        assert n == core * scale**5 and scale % 5
        assert all(core % k**5 for k in range(2, 5))
        status = row["classification"]
        assert (status == "mod 11") == (n % 11 in (4, 5, 6, 7))
        if status == "reciprocity":
            excluded.add(n)
            cores.add(core)
        if status == "represented":
            triple = tuple(map(int, row["signed_witness"].split()))
            assert len(triple) == 3 and sum(x**5 for x in triple) == n
            represented[n] = triple
        else:
            assert not row["signed_witness"]

    with (ROOT / "reciprocity" / "targets.csv").open(newline="") as stream:
        restricted = [row for row in csv.DictReader(stream)
                      if row["status"] != "outside scope"]
    failed = [int(row["target"]) for row in restricted
              if row["status"] == "reciprocity obstruction"]
    admissible = {n for n in failed if n % 11 not in (4, 5, 6, 7)}
    assert len(restricted) == 559 and len(failed) == 93
    assert len(admissible) == 57 and admissible <= excluded
    assert len(cores) == 101

    # Check the chosen minimum height and lexicographic tie-break directly.
    minima = {}
    for x, y, z in combinations_with_replacement(range(-34, 35), 3):
        n = x**5 + y**5 + z**5
        if 1 <= n <= 1000:
            candidate = (max(-x, z), x, y, z)
            if n not in minima or candidate < minima[n]:
                minima[n] = candidate
    with (ROOT / "witnesses" / "represented.csv").open(newline="") as stream:
        expected = {int(row["n"]): tuple(int(row[key]) for key in
                    ("minimum_height", "x", "y", "z")) for row in csv.DictReader(stream)}
    assert minima == expected
    assert represented == {n: entry[1:] for n, entry in expected.items()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--height-search", action="store_true",
                        help="also build and repeat the exhaustive C++ search to height 10,000")
    args = parser.parse_args()

    with tempfile.TemporaryDirectory() as directory:
        temporary = Path(directory)
        run_python("local/check.py")
        run_python("reciprocity/classify.py", "--csv", temporary / "restricted.csv")
        assert_match(temporary / "restricted.csv", "reciprocity/targets.csv")
        run_python("reciprocity/crosscheck.py")
        print("Reproduced the restricted test and its independent character calculation.", flush=True)
        run_python("survey/catalogue.py", "--output", temporary / "catalogue.csv")
        assert_match(temporary / "catalogue.csv", "targets-1-1000.csv")
        verify_catalogue()
        print("Catalogue reproduced: 44 witnesses, 364 mod-11 exclusions, "
              "108 reciprocity exclusions, 484 undecided.", flush=True)
        run_python("wild/wild.py")
        run_python("wild/check_opposite.py")
        split = json.loads(run_python("survey/tests/split_prime.py"))
        recorded = json.loads((ROOT / "survey" / "tests" / "split_prime.json").read_text())
        assert split == recorded
        print("Verified the calibrations at 5 and all split-prime controls.", flush=True)

        if args.height_search:
            binary = temporary / "scan"
            subprocess.run(["c++", "-O3", "-std=c++17", str(ROOT / "witnesses" / "scan.cpp"),
                            "-o", str(binary)], check=True)
            with (temporary / "witnesses.csv").open("wb") as output:
                subprocess.run([str(binary)], stdout=output, check=True)
            assert_match(temporary / "witnesses.csv", "witnesses/represented.csv")
            print("The exhaustive height-10,000 search reproduced the witness table.", flush=True)


if __name__ == "__main__":
    main()
