# Sums of three signed fifth powers through 1,000

For each integer $1\le n\le1000$ we test whether $x^5+y^5+z^5=n$ has a solution in signed integers. Zero and repeated coordinates are allowed. The main paper proves the global exclusions for $8,9,42$ and treats rational representations of those numbers with denominator prime to five. This supplement gives the complete target table and the arithmetic behind its additional computer-assisted exclusions. The table counts targets, so an exclusion for a fifth-power multiple can contribute a second row.

| Targets | Exhibited triple | Excluded modulo 11 | Further exclusions by reciprocity | Undecided |
|---|---:|---:|---:|---:|
| 1–12 | 4 | 4 | 3 | 1 |
| 1–100 | 13 | 36 | 23 | 28 |
| 1–1,000 | 44 | 364 | 108 | 484 |

The 108 reciprocity rows, including the three target values of the article, have **101 distinct fifth-power-free parts**. Among the first twelve targets, $1,2,3,12$ have witnesses, $4$ through $7$ fail modulo 11, and reciprocity excludes $8,9,10$. The first undecided target here is $11$. The smallest undecided value need not be insoluble. [Full table](targets-1-1000.csv) · [Calculation for 10](wild/method.md)

## Interpreting a row

The columns `fifth_power_free_part` and `scale` give $m$ and $d$ in $n=md^5$. The final column contains three space-separated signed integers whenever the classification is `represented`. The exact witness for $12$, for example, is $(-17,13,16)$. The witness table also gives the smallest possible height $\max(|x|,|y|,|z|)$ for each of the 44 exhibited targets. [Witnesses](witnesses/represented.csv)

A row marked `mod 11` has remainder $4,5,6$ or $7$ on division by 11. Every other target passes all ordinary congruence tests. For primes other than 11 this follows from the local Waring numbers of Kowalczyk and Miska. At 11, each of the remaining residues has a triple with a unit coordinate, which lifts by Hensel’s lemma. A row marked `reciprocity` fails the joint character test described below. A row marked `undecided` passes those tests and has no witness in the search cube. The exclusions apply at every height. [Kowalczyk and Miska, *Mathematika* 70 (2024), e12276, Table 3](https://arxiv.org/pdf/2206.09904#page=25) · [Reciprocity computation](method.md)

## Search and independent checks

The signed search covers every ordered choice of coordinates up to permutation with height at most 10,000. After sorting $x\le y\le z$, fix $x$ and increase $y$. The largest feasible $z$ for the upper target bound can only decrease. The program visits every $z\ge y$ in the corresponding interval down to the lower target bound. It uses signed 128-bit arithmetic for all power sums. For each target, it minimizes the tuple $(\mathrm{height},x,y,z)$ in lexicographic order. Every smaller height lies within the completed cube. A separate direct enumeration at height 34 reproduces the same 44 minimum-height triples. [Search implementation](witnesses/scan.cpp) · [Independent enumeration](verify.py)

Palcoux’s 2015 question reports the same thirteen positive targets through 100, including the identity for $12$. Guruprasad later reported a search through $1\le n<1000$ with $|x|,|y|,|z|<10^7$. The height bound reproduced here is 10,000. [Palcoux’s question and Guruprasad’s report](https://math.stackexchange.com/questions/1524797/can-a-sum-of-three-fifth-power-of-integers-be-8)

The restricted test applies to 559 fifth-power-free targets coprime to 5 whose prime divisors are all incongruent to 1 modulo 5. Two character implementations agree across that range. There are 93 failures, of which 57 pass the mod-11 criterion. All 57 are among the 108 in the full catalogue. The full test also handles fully split primes, multiples of 5, and fifth-power scaling. The formal Lean calculation accompanying the main paper covers its finite contradiction for 42 under the stated reciprocity identities. The wider computation has been replayed and awaits independent specialist review. [Restricted table](reciprocity/targets.csv) · [Independent character calculation](reciprocity/crosscheck.py) · [Split-prime checks](survey/tests/split_prime.py) · [Checks at 5](wild/check_opposite.py)

## Reproduction

Run from this directory with Python 3.9 or later. The replay uses the Python standard library and compares both regenerated target tables with the supplied CSV files. It also checks the signed witnesses, repeats the restricted character calculation, and tests the formulas at 5 and at split primes.

```sh
python3 -B verify.py
```

To include the full height-10,000 witness search in the same replay, use a C++17 compiler with signed 128-bit integer support (GCC or Clang) available as `c++`.

```sh
python3 -B verify.py --height-search
```

To generate your own copy of the catalogue, select an output path.

```sh
python3 -B survey/catalogue.py --output reproduced.csv
```
