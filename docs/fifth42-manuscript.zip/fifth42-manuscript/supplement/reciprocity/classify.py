"""Necessary quintic reciprocity test for fifth-power-free targets, m coprime to 5."""
import argparse
import csv
from functools import cache
from itertools import combinations_with_replacement, product
from pathlib import Path

PAIRS = ((0, 1), (0, 2), (1, 2))


def factor(n):
    out = []
    p = 2
    while p*p <= n:
        e = 0
        while n % p == 0:
            n //= p
            e += 1
        if e:
            out.append((p, e))
        p += 1
    if n > 1:
        out.append((n, 1))
    return out


@cache
def residue_factors(p):
    """Monic irreducible factors of Phi_5 over F_p, coefficient of highest degree omitted."""
    if p % 5 in (2,3):
        return ((1,1,1,1),)
    if p % 5 == 4:
        roots = [r for r in range(p) if (r*r+r-1)%p == 0]
        assert len(roots) == 2
        return tuple((1,-r) for r in roots)
    raise ValueError('unsupported prime')


def elt_mul(a,b,f,p):
    d = len(f)
    c = [0]*(2*d-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):
            c[i+j] += x*y
    for k in range(len(c)-1, d-1, -1):
        for j,z in enumerate(f):
            c[k-d+j] -= c[k]*z
    return tuple(x%p for x in c[:d])


def elt_pow(a,n,f,p):
    b = (1,)+(0,)*(len(f)-1)
    while n:
        if n%2:
            b = elt_mul(b,a,f,p)
        a = elt_mul(a,a,f,p)
        n //= 2
    return b


@cache
def roots(f,p):
    zeta = (0,1)+(0,)*(len(f)-2)
    out = tuple(elt_pow(zeta,j,f,p) for j in range(5))
    assert len(set(out)) == 5 and elt_pow(zeta,5,f,p) == out[0]
    return out


@cache
def normalized_symbol(p,u,v):
    exponent = 0
    for f in residue_factors(p):
        d = len(f)
        value = elt_pow((u,v)+(0,)*(d-2), (p**d-1)//5, f,p)
        exponent += roots(f,p).index(value)
    return exponent % 5


def symbol(p,u,v):
    # Rational units have trivial fifth-power residue character here.
    if u%p:
        return normalized_symbol(p,1,v*pow(u,-1,p)%p)
    assert v%p
    return normalized_symbol(p,0,1)


@cache
def local_symbols(p):
    fifth_roots = {pow(r,5,p):r for r in range(p)}
    assert len(fifth_roots) == p
    # A nonzero Fermat triple mod p with first nonzero entry normalized to one.
    tuples = [(0,1,p-1)] + [(1,y,fifth_roots[(-1-pow(y,5,p))%p]) for y in range(p)]
    return {tuple(symbol(p,t[i],t[j]) for i,j in PAIRS) for t in tuples}


@cache
def labels_mod25(r):
    return tuple(t for t in combinations_with_replacement(range(5),3) if sum(v**5 for v in t)%25==r)


def classify(n):
    labels = labels_mod25(n%25)
    if not labels:
        return 'mod-25 obstruction'
    factors = factor(n)
    if any(p%5 in (0,1) or e>=5 for p,e in factors):
        return 'outside scope'
    possible = {(0,0,0)}
    corr = 0
    for p,e in factors:
        corr = (corr + e*symbol(p,0,1))%5
        possible = {tuple((x+e*y)%5 for x,y in zip(old,new))
                    for old in possible for new in local_symbols(p)}
    for t in labels:
        target = {}
        for ix,(i,j) in enumerate(PAIRS):
            if (t[i]+t[j])%5:
                target[ix] = corr*t[j]*pow(t[i]+t[j],-1,5)%5
        if any(all(s[ix]==exp for ix,exp in target.items()) for s in possible):
            return 'passes tested reciprocity conditions'
    return 'reciprocity obstruction'


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--limit',type=int,default=1000)
    ap.add_argument('--csv',type=Path,default=Path(__file__).with_name('targets.csv'))
    args=ap.parse_args()
    results = {n:classify(n) for n in range(1,args.limit+1)}
    with args.csv.open('w',newline='') as f:
        w=csv.writer(f)
        w.writerow(('target','status'))
        w.writerows(results.items())
    for status in sorted(set(results.values())):
        values = [n for n,kind in results.items() if kind==status]
        print(status,len(values),'through 100:',[n for n in values if n<=100])
    discovered = {a**5+b**5+c**5 for a,b,c in combinations_with_replacement(range(-30,31),3)}
    assert all(results[n] not in ('reciprocity obstruction','mod-25 obstruction') for n in discovered if n in results)
    assert classify(8) == classify(42) == 'reciprocity obstruction'

if __name__=='__main__':
    main()
