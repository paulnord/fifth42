"""Cross-check exclusions by powering polynomials modulo Phi_5 for both splitting types."""
import csv
from functools import cache
from itertools import product
from pathlib import Path
from classify import factor, labels_mod25


def multiply(a,b,p):
    r = [0]*5
    for i,x in enumerate(a):
        for j,y in enumerate(b):
            r[(i+j)%5] += x*y
    return tuple((r[i]-r[4])%p for i in range(4))


def power(a,n,p):
    v = (1,0,0,0)
    for bit in bin(n)[2:]:
        v = multiply(v,v,p)
        if bit=='1':
            v = multiply(v,a,p)
    return v


@cache
def norm_character(p,s,t):
    X=(0,1,0,0)
    if p%5 in (2,3):
        w=power((s,t,0,0),(p**4-1)//5,p)
    else:
        # Two primes, represented by embeddings ζ→X and ζ→X².
        # Raise the second contribution to 3 to express it relative to X².
        q=(p*p-1)//5
        w=multiply(power((s,t,0,0),q,p),power((s,0,t,0),3*q,p),p)
    return [power(X,k,p) for k in range(5)].index(w)


def symbol(p,u,v):
    if v%p==0:
        assert u%p
        return 0
    return norm_character(p,(u*pow(v,-1,p))%p,1)


@cache
def alternatives(p):
    # Normalize the *last* nonzero coordinate. Enumerate via y, solve directly for x.
    d = pow(5,-1,p-1) if p>2 else 1
    zs=[(p-1,1,0)]
    for y in range(p):
        x=pow((-pow(y,5,p)-1)%p,d,p)
        zs.append((x,y,1))
    return {tuple(symbol(p,z[i],z[j]) for i,j in ((0,1),(0,2),(1,2))) for z in zs}


def contradiction(n):
    factors=factor(n)
    possible={(0,0,0)}
    for p,e in factors:
        possible={tuple((x+e*y)%5 for x,y in zip(l,r)) for l in possible for r in alternatives(p)}
    corr=sum(e*norm_character(p,0,1) for p,e in factors)
    for a,b,c in product(range(5),repeat=3):
        if (a**5+b**5+c**5-n)%25: continue
        # Cross-multiply the congruence; skip pairs with sum zero modulo five.
        for vec in possible:
            if all((u+v)%5==0 or (s*(u+v)-corr*v)%5==0
                   for (u,v),s in zip(((a,b),(a,c),(b,c)),vec)):
                return False
    return True


if __name__=='__main__':
    counts=[0,0]
    for row in csv.DictReader(Path(__file__).with_name('targets.csv').open()):
        if row['status']=='outside scope': continue
        n=int(row['target'])
        expected=row['status']=='reciprocity obstruction'
        assert contradiction(n)==expected,n
        counts[expected]+=1
    print('Independent polynomial-arithmetic cross-check:',counts[0],'passing and',counts[1],'excluded.')
