"""Check the split-prime singular substitution by direct tame local symbols."""
import json
import sys
from itertools import product
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from catalogue import fifth_roots_of_one, split_pair


def vp(a,p):
    assert a
    e=0
    while a%p==0:
        a//=p
        e+=1
    return e


def lift_root(r,p,k):
    mod=p
    for _ in range(1,k):
        correction=((pow(r,5,mod*p)-1)//mod*pow(5*r**4,-1,p))%p
        r-=correction*mod
        mod*=p
        r%=mod
    assert pow(r,5,mod)==1
    return r


def which_exponent(p,r,value):
    return next(e for e in range(5) if pow(r,e,p)==pow(value,(p-1)//5,p))


def direct_pair(p,m,u,v):
    e=vp(m,p)
    out=0
    for r in fifth_roots_of_one(p):
        k=2
        while True:
            lifted=lift_root(r,p,k)
            residue=(u+v*lifted)%p**k
            if residue:
                break
            k*=2
        d=vp(residue,p)
        actual_unit=residue//p**d
        m_unit=m//p**e
        # (-1)^(de) is always a fifth power.
        direct=pow(actual_unit,e,p)*pow(m_unit,-d,p)%p
        out+=which_exponent(p,r,direct)
    return out%5


def tests():
    summary={}
    for p in (11,31,41,61,71):
        control=0
        singular=0
        for u,v in product(range(-9,10),repeat=2):
            if not (u%p or v%p):
                continue
            for w in range(0,10):
                n=u**5+v**5+w**5
                if n==0 or n%p or vp(n,p)>=5:
                    continue
                actual=direct_pair(p,n,u,v)
                assert actual==vp(n,p)*split_pair(p,u,v)%5
                singular+=any((u+r*v)%p==0 for r in fifth_roots_of_one(p))
                control+=1
        # Rational control with common denominator p and p|target.
        # Choose u so u^5+1 is congruent to -p^5 mod p^6. Then
        # (u/p)^5+(1/p)^5+1^5 is an integer divisible by p.
        r=fifth_roots_of_one(p)[0]
        U=-lift_root(r,p,7)
        U+=p**5*((-pow(5*U**4,-1,p))%p)
        m=(U**5+1)//p**5+1
        while m and vp(m,p)>=5:
            U+=p**6
            m=(U**5+1)//p**5+1
        assert U**5+1+p**5==m*p**5 and 0<vp(m,p)<5
        assert direct_pair(p,m,U,1)==vp(m,p)*split_pair(p,U,1)%5
        summary[p]=dict(integer_controls=control,integer_singular=singular,rational_control=True)
    return summary


if __name__=='__main__':
    print(json.dumps(tests(),indent=2))
