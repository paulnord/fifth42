"""A finite necessary test for a rational representation integral at 5."""
import argparse
from functools import cache
from pathlib import Path
from collections import Counter
import csv
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'reciprocity'))
import classify as simple
sys.path.insert(0, str(ROOT/'wild'))
import wild

PAIRS = simple.PAIRS


@cache
def fifth_roots_of_one(p):
    return tuple(t for t in range(2,p) if pow(t,5,p)==1)


@cache
def split_pair(p, u, v):
    # For the local solution with the given reduction, use the residue unit
    # (u + zeta*v) if nonzero, and the inverse product of its four siblings
    # if zero. Both formulas use the same exponent since the product is a norm.
    acc = 0
    for zeta in fifth_roots_of_one(p):
        value = (u+zeta*v)%p
        if value == 0:
            value = pow(5*pow(u,4,p),-1,p)
        roots = [pow(zeta,k,p) for k in range(5)]
        acc += roots.index(pow(value,(p-1)//5,p))
    return acc%5


@cache
def local_rows(p):
    if p%5!=1:
        return simple.local_symbols(p)
    roots = {}
    for t in range(p):
        roots.setdefault(pow(t,5,p),[]).append(t)
    projective = [(0,1,z) for z in roots[p-1]]
    projective.extend((1,y,z) for y in range(p) for z in roots.get((-1-pow(y,5,p))%p,[]))
    return {tuple(split_pair(p,t[i],t[j]) for i,j in PAIRS) for t in projective}


def forced_away_from_five(m):
    # For a pair with u+v a 5-adic unit and m prime to 5,
    # its primary correction is h times the exponent of (zeta/m).
    if m%25 in (1,24,7,18):
        # Locally a fifth power at 5, even for pairs with nonunit sum.
        yield (0,0,0)
        return
    mod5 = 0
    for p,e in simple.factor(m):
        f = {1:1,4:2,2:4,3:4}[p%5]
        mod5 += e*(4//f)*((p**f-1)//5)
    for t in simple.labels_mod25(m%25):
        yield tuple(mod5*t[j]*pow(t[i]+t[j],-1,5)%5 if (t[i]+t[j])%5 else None
                    for i,j in PAIRS)


@cache
def reciprocity_status(m):
    facts = simple.factor(m)
    if any(e>=5 for p,e in facts):
        raise ValueError('test expects fifth-power-free m')
    possible = {(0,0,0)}
    for p,e in facts:
        if p==5:
            continue
        added = local_rows(p)
        possible = {tuple((a+e*b)%5 for a,b in zip(r,s)) for r in possible for s in added}
        if len(possible)==125:
            return 'undecided'
    if m%5:
        wanted = forced_away_from_five(m)
    elif m%25:
        wanted = wild.wild_rows(m)
    else:
        wanted = wild.sharp_wild_rows(m)
    for row in wanted:
        if any(all(a is None or a==b for a,b in zip(row,r)) for r in possible):
            return 'undecided'
    return 'reciprocity'


def reduce_target(n):
    scale=1
    for p,e in simple.factor(n):
        scale*=p**(e//5)
    if scale%5==0:
        raise ValueError('division by scale must preserve integrality at 5')
    return n//scale**5,scale


def run(output_path):
    with (ROOT/'witnesses'/'represented.csv').open() as f:
        assert next(csv.reader(f)) == ['n','x','y','z','minimum_height']
        witnesses={int(r[0]):tuple(map(int,r[1:4])) for r in csv.reader(f)}
    results={}
    for n in range(1,1001):
        core,scale=reduce_target(n)
        status = 'mod 11' if 4<=n%11<=7 else reciprocity_status(core)
        witnesses_str=''
        if n in witnesses:
            assert sum(a**5 for a in witnesses[n]) == n and status=='undecided'
            status='represented'
            witnesses_str=' '.join(map(str,witnesses[n]))
        results[n]=status,core,scale,witnesses_str
    with output_path.open('w',newline='') as f:
        out=csv.writer(f)
        out.writerow(['target','classification','fifth_power_free_part','scale','signed_witness'])
        for n,row in results.items():
            out.writerow([n,*row])
    print(Counter(v[0] for v in results.values()))
    for status in ('mod 11','reciprocity','represented','undecided'):
        print(status,[n for n,v in results.items() if v[0]==status and n<=100])
    return results


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "targets-1-1000.csv")
    run(parser.parse_args().output)
