"""Quintic character constraints supplied by the completion at 5."""
from functools import cache
from itertools import product
from math import gcd
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "reciprocity"))
from classify import PAIRS, factor, labels_mod25, symbol


@cache
def unit_pair_symbol(p, u, v):
    """Tame exponent summed over all primes above p for an everywhere unit pair."""
    if p % 5 != 1:
        return symbol(p, u, v)
    generator = next(pow(x, (p-1)//5, p) for x in range(2,p)
                     if pow(x, (p-1)//5, p) != 1)
    result = 0
    for i in range(1,5):
        zeta = pow(generator,i,p)
        residue = (u+v*zeta) % p
        assert residue, "calibrating element divisible by a prime of the numerator"
        log_table = [pow(zeta,k,p) for k in range(5)]
        result += log_table.index(pow(residue,(p-1)//5,p))
    return result % 5


def representatives(h):
    start = (h+12) % 25-12
    yield start
    offset = 25
    while True:
        yield start+offset
        yield start-offset
        offset += 25


@cache
def prime_divisors(n):
    return tuple(factor(n))


@cache
def calibration(m, h):
    """Direct global calibration for -log_zeta (m,1+h*(zeta-1))_5."""
    assert m != 0
    k = next(k for k in representatives(h) if gcd((1-k)**5+k**5,m)==1)
    norm = (1-k)**5+k**5
    total = sum(e*unit_pair_symbol(p,(1-k)%p,k%p) for p,e in prime_divisors(abs(m)) if p!=5)
    for q,e in prime_divisors(norm):
        zeta = (1-pow(k,-1,q))%q
        assert q%5==1 and zeta!=1 and pow(zeta,5,q)==1
        logs = [pow(zeta,j,q) for j in range(5)]
        total -= e*logs.index(pow(m,(q-1)//5,q))
    return total % 5


def exponent_profile(m):
    b, e = m, 0
    if b == 0:
        raise ValueError("use the obvious integer representation for zero")
    while b%5==0:
        b//=5
        e+=1
    q5 = (pow(b,4,25)-1)//5
    return tuple((q5*h+e*calibration(5,h))%5 for h in range(25))


@cache
def lifted_ratios(n125, allow_all_five):
    """Residues mod 25 suffice to compute fifth powers mod 125."""
    out=set()
    for labels in labels_mod25(n125%25):
        if labels==(0,0,0) and not allow_all_five:
            continue
        for triple in product(*(range(t,25,5) for t in labels)):
            if sum(x**5 for x in triple)%125 != n125:
                continue
            ratios = []
            for i,j in PAIRS:
                u,v = triple[i],triple[j]
                ratios.append(v*pow(u+v,-1,25)%25 if (u+v)%5 else None)
            out.add(tuple(ratios))
    return frozenset(out)


@cache
def wild_rows(m):
    """Allowed exponent triples at 5 in pair order (01,02,12); None is free."""
    exponents = exponent_profile(m)
    return frozenset(tuple(None if h is None else exponents[h] for h in r)
                     for r in lifted_ratios(m%125, m%3125==0))


if __name__ == "__main__":
    for n in range(1,1001):
        expected = tuple(calibration(n,h) for h in range(25))
        assert expected == exponent_profile(n), n
    print("Matched direct global calibration for 25 residue classes and each of 1,000 targets.")
    for n in (5,8,10,12,25,42,125,625):
        print(n, "distinct wild rows", len(wild_rows(n)), "examples", list(wild_rows(n))[:5])
    print("Wild correction for m=5:", exponent_profile(5))


def opposite_representatives(r):
    start=(r+62)%125-62
    yield start
    offset=125
    while True:
        yield start+offset
        yield start-offset
        offset+=125


def norm_k_plus_zeta(k):
    return k**4-k**3+k*k-k+1


@cache
def opposite_calibration(m,r):
    """Needed tame exponent for u+zeta*v, v unit and u/v=r=-1 (mod 5)."""
    assert r%5==4 and m
    b=m
    while b%5==0:
        b//=5
    k=next(k for k in opposite_representatives(r) if gcd(norm_k_plus_zeta(k),b)==1)
    total=sum(e*unit_pair_symbol(p,k%p,1) for p,e in prime_divisors(abs(b)))
    for q,e in prime_divisors(norm_k_plus_zeta(k)):
        if q==5:
            continue
        zeta=(-k)%q
        assert q%5==1 and zeta!=1 and pow(zeta,5,q)==1
        logs=[pow(zeta,j,q) for j in range(5)]
        total-=e*logs.index(pow(m,(q-1)//5,q))
    return total%5


@cache
def wild_lifts_125(m625):
    """Simultaneous ratio arguments for unit-sum and opposite-unit pairs."""
    rows=set()
    for labels in labels_mod25(m625%25):
        if labels==(0,0,0):
            continue
        lifts=[[ (a,pow(a,5,625)) for a in range(l,125,5)] for l in labels]
        for row in product(*lifts):
            if sum(v for _,v in row)%625!=m625:
                continue
            triple=[a for a,_ in row]
            pairs=[]
            for i,j in PAIRS:
                u,v=triple[i],triple[j]
                if (u+v)%5:
                    pairs.append(('sum',v*pow(u+v,-1,25)%25))
                elif v%5:
                    pairs.append(('opposite',u*pow(v,-1,125)%125))
                else:
                    pairs.append(('free',0))
            rows.add(tuple(pairs))
    return rows


@cache
def sharp_wild_rows(m):
    """Complete joint exponents at 5 for 25|m, 5^5 not dividing m."""
    if not m or m%25 or not m%3125:
        raise ValueError("requires 25 dividing target and v5(target)<5")
    regular=exponent_profile(m)
    def decode(which, value):
        if which=='sum':
            return regular[value]
        if which=='opposite':
            return opposite_calibration(m,value)
        raise AssertionError("expected at least one unit in each pair")
    return frozenset(tuple(decode(*pair) for pair in row) for row in wild_lifts_125(m%625))
