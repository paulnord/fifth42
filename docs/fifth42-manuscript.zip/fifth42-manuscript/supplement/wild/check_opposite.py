"""Stress-test calibration at alternative representatives and against attained targets."""
from itertools import combinations_with_replacement

from wild import (PAIRS, norm_k_plus_zeta, opposite_calibration, opposite_representatives,
                  prime_divisors, sharp_wild_rows, symbol, unit_pair_symbol, wild_rows)


def alternate_tame_total(m, k):
    N = norm_k_plus_zeta(k)
    numerator = [(p, e) for p, e in prime_divisors(abs(m)) if p != 5]
    assert all(N % p for p, _ in numerator)
    exponent = sum(e*unit_pair_symbol(p,k%p,1) for p,e in numerator)
    for q, e in prime_divisors(N):
        if q == 5:
            continue
        value=pow(m,(q-1)//5,q)
        zeta=(-k)%q
        j=next(j for j in range(5) if pow(zeta,j,q)==value)
        exponent-=e*j
    return exponent%5


def main():
    for m in range(25,1001,25):
        for r in range(4,125,5):
            gen=opposite_representatives(r)
            coprime=(k for k in gen if all(norm_k_plus_zeta(k)%p
                                          for p,_ in prime_divisors(m) if p!=5))
            next(coprime)
            second=next(coprime)
            assert alternate_tame_total(m,second)==opposite_calibration(m,r)
        for row in sharp_wild_rows(m):
            assert any(all(x is None or x==y for x,y in zip(weak,row)) for weak in wild_rows(m))
    print('All 1000 opposite-unit calibration values reproduced at alternative representatives.')
    count=0
    for triple in combinations_with_replacement(range(-14,15),3):
        m=sum(x**5 for x in triple)
        if m<=0 or m%25 or not m%3125:
            continue
        f=prime_divisors(m)
        if any(p%5==1 or e>=5 for p,e in f):
            continue
        t=sorted(triple,key=lambda x:x%5)
        expected=tuple(sum(e*symbol(p,t[i],t[j]) for p,e in f if p!=5)%5 for i,j in PAIRS)
        assert expected in sharp_wild_rows(m),(triple,m,expected)
        count+=1
    assert count==76
    print('Matched the actual three tame exponents for all 76 attained controls in the stated test.')

if __name__=='__main__':
    main()
