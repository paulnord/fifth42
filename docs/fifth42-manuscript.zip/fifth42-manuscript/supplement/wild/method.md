# Computing the fifth Hilbert symbol at 5

Fix a nonzero integer target $m$, set $F=\mathbf Q(\zeta_5)$, and put $\pi=\zeta_5-1$. For a candidate signed pair $u,v$ with $5\nmid u+v$, set $h=v/(u+v)\pmod{25}$. Use the symbol convention in which the first input is a uniformizer and the second is a unit at a tame prime $P$. The output reduces to the unit raised to $(N(P)-1)/5$. The quantity needed by the global sieve is
$$W_m(h)=-\log_{\zeta_5}(m,u+\zeta_5v)_\pi,$$
so the other places must contribute $W_m(h)$ in total.

## Matching a small calibration element

The local Hilbert symbol of two rational $5$-adic numbers is trivial by Galois equivariance. The fixed subgroup of $\mu_5$ under $\operatorname{Gal}(\mathbf Q_5(\zeta_5)/\mathbf Q_5)$ is trivial. Removing the rational factor $u+v$ leaves $1+\pi v/(u+v)$. For every rational integer $k\equiv h\pmod{25}$ its ratio with $\beta_k=1+k\pi$ lies in $1+\pi^9\mathcal O$. Hensel's criterion at $X=1$ for $X^5$ shows such a unit is a fifth power, since $9>2v_\pi(5)=8$. This argument works even when $5\mid m$.

Choose $k$ in this residue class with $\gcd((1-k)^5+k^5,m)=1$. Such a choice exists by taking $k\equiv0$ at all prime divisors of $m$ other than 5, since the norm is always $1$ modulo 5. The code tries nearby representatives until this condition holds. The norm of $\beta_k$ is $N=(1-k)^5+k^5$. For every prime $q\mid N$, $q\nmid5k$ and $1-1/k$ has order five modulo $q$. This identifies the unique prime over $q$ dividing $\beta_k$, with valuation $v_q(N)$ and residue field $\mathbf F_q$. Its contribution to $(m,\beta_k)$ is minus $v_q(N)$ times the discrete log, base $1-1/k$, of $m^{(q-1)/5}\bmod q$. The minus sign comes from taking the nonunit in the second slot. At each prime over $p\mid m$, $p\ne5$, the calibrator is a unit. Its contribution is $v_p(m)$ times the log of $\beta_k^{(p^f-1)/5}$ in that residue field, $f$ being the order of $p$ modulo 5. Summing the contributions gives $W_m(h)$ by the global product formula. [Venjakob, §4.1, tame Hilbert symbol and the product formula](https://www.mathi.uni-heidelberg.de/~otmar/papervenjakob/explizitreciprocityLaw.pdf)

## A second calculation

Write $m=5^a b$, $5\nmid b$, and use multiplicativity. For rational $b$ prime to five, dividing $\beta_k$ by $\zeta_5^k$ makes it primary, since the quotient is $1$ modulo $\pi^2$. Eisenstein reciprocity identifies the numerator and denominator power residue symbols, cancelling every non-5 contribution except the primary correction. Thus
$$W_m(h)=h\frac{b^4-1}{5}+a\,W_5(h)\pmod5.$$
Indeed the exponent of $(\zeta_5/(b))_5$ is $(b^4-1)/5$ modulo 5. At a prime ideal $P\mid b$ its exponent is $(N(P)-1)/5$, counted with multiplicity. Adding these exponents modulo five agrees with taking $(N((b))-1)/5$ because each $N(P)\equiv1\pmod5$. The ideal norm is $b^4$. The case $b=\pm1$ has zero correction. If the calibrating primary element is a unit, one can multiply it by a rational fifth power coprime to $5b$ without affecting either residue symbol. [Spearman and Williams, equation (1.1)](https://people.math.carleton.ca/~williams/papers/pdf/142.pdf)

In increasing order $h=0,1,\dots,24$, the values $W_5(h)$ are
$$0,0,0,2,4,\ 4,4,4,1,3,\ 3,3,3,0,2,\ 2,2,2,4,1,\ 1,1,1,3,0.$$
For each $m$ the code enumerates possible residue triples modulo 25 from the equation modulo 125. The fifth power modulo 125 depends only on the coordinate modulo 25. Coordinates are ordered by their residues modulo 5, allowing every order inside ties. For a pair whose sum is divisible by 5 the implementation leaves its exponent unrestricted. The returned finite set of joint rows contains every possible row for an integer solution.

## Check for 10

Modulo 25 the only sorted base residues for 10 are $(3,3,4)$. Their lifts modulo 25 satisfying the equation modulo 125 yield just five distinct wild rows in pair order $(01,02,12)$, namely
$$(0,3,1),(1,4,0),(2,0,4),(3,1,3),(4,2,2).$$
At 2 the triple modulo 2 contains exactly two ones because $v_2(10)=1$. Computing the characters in $\mathbf F_{16}$ gives $(0,4,3),(3,3,4),(4,0,0)$. For an integer solution every place away from 2 and 5 contributes zero, since at every prime there dividing $u+\zeta_5v$, the fifth power of the remaining coordinate is 10 in that residue field. The two lists are disjoint, excluding 10 at every height.

From the supplement directory, run `python3 -B wild/wild.py` to check all unit-sum calibration values for the first 1,000 positive targets in two ways. The catalogue uses `wild_rows(m)` when $5\parallel m$ and `sharp_wild_rows(m)` when $25\mid m$.

## Opposite units at 5

For $25\mid m$ and $5^5\nmid m$, the possible primitive base residues modulo 5 are permutations of $(0,1,4)$ and $(0,2,3)$. Indeed these have opposite nonzero fifth powers modulo 25, and the all-zero triple would force $5^5\mid m$. For the pair of opposite units, write $r=u/v\bmod125$. Now $r\equiv-1\pmod5$. Select $k\equiv r\pmod{125}$ so that $N=k^4-k^3+k^2-k+1$ is coprime to the part of $m$ away from 5. Such a $k$ exists by taking $k=0$ modulo each prime factor of that part. Both $u/v+\zeta_5$ and $k+\zeta_5$ have $\pi$-adic valuation exactly one, since $k+1$ is divisible by 5 and $\zeta_5-1$ has valuation one. Their quotient belongs to $1+\pi^{11}\mathcal O$ since the difference is divisible by 125. It is therefore a fifth power. As before, removing the rational factor $v$ leaves the symbol unchanged.

Compute the tame sum for the calibrator $k+\zeta_5$. At primes over divisors of $m$ outside 5 use the unit formula, and at each prime $q\mid N$ with $q\ne5$, use the unique divisor with $\zeta_5\equiv -k\bmod q$ and subtract the discrete-log contribution of $m$ with multiplicity $v_q(N)$. As $N$ is the norm of $k+\zeta_5$, all other tame symbols are trivial. The prime 5 itself is excluded from this sum. By reciprocity the result is the required tame sum for the candidate pair.

Testing the original equation modulo 625 uses only base residues modulo 125. The function `sharp_wild_rows` tests every triple with coordinates in that residue domain and their labels in nondecreasing order. All three resulting pair exponents are retained together. At each accepted triple one coordinate is a unit. Changing it by a multiple of $5^{k-1}$ lifts the congruence modulo $5^k$ to the next power for $k\ge4$ while preserving all base residues modulo 125. Thus the output is exact for the local equation at 5 with these target valuations. From the supplement directory run `python3 -B wild/check_opposite.py` to check all targets $25,50,\dots,1000$ by moving each calibration to a different representative and to check 76 attained targets/triples directly against their actual tame sums.
