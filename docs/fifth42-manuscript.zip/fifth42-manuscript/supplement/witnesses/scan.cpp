// All sorted signed triples in [-10000,10000] whose sum is in [1,1000].
// The largest feasible third coordinate is monotone as the second increases.
#include <algorithm>
#include <array>
#include <cstdlib>
#include <iostream>
#include <tuple>

int main() {
    constexpr int height = 10000;
    constexpr int limit = 1000;
    using Wide = __int128_t;
    using Witness = std::tuple<int, int, int, int>;
    std::array<Wide, 2*height+1> powers;
    std::array<Witness, limit+1> best;
    best.fill({height+1, 0, 0, 0});
    for (int i=-height; i<=height; ++i)
        powers[i+height] = Wide(i)*i*i*i*i;
    for (int x=-height; x<=height; ++x) {
        int last = height;
        for (int y=x; y<=last; ++y) {
            const Wide sum = powers[x+height] + powers[y+height];
            while (last>=y && sum+powers[last+height]>limit) --last;
            for (int z=last; z>=y; --z) {
                const Wide target = sum + powers[z+height];
                if (target<1) break;
                const int h = std::max(-x,z);
                auto &entry = best[static_cast<int>(target)];
                entry = std::min(entry, Witness{h,x,y,z});
            }
        }
    }
    std::cout << "n,x,y,z,minimum_height\n";
    for (int n=1;n<=limit;++n) {
        auto [h,x,y,z] = best[n];
        if (h<=height) std::cout << n << ',' << x << ',' << y << ',' << z << ',' << h << '\n';
    }
}
