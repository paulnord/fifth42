"""Verify the finite residue computations in the classification of local targets."""

from itertools import combinations_with_replacement
from math import isqrt


def primes_below(bound):
    return [
        n for n in range(2, bound)
        if all(n % d != 0 for d in range(2, isqrt(n) + 1))
    ]


def primitive_sums(modulus, prime):
    powers = {pow(x, 5, modulus) for x in range(modulus)}
    return {
        sum(row) % modulus
        for row in combinations_with_replacement(sorted(powers), 3)
        if any(value % prime for value in row)
    }


def main():
    small_primes = [p for p in primes_below(157) if p % 5 == 1]
    assert small_primes == [11, 31, 41, 61, 71, 101, 131, 151]
    for modulus, prime in [(25, 5)] + [(p, p) for p in small_primes]:
        found = primitive_sums(modulus, prime)
        missing = sorted(set(range(modulus)) - found)
        assert missing == ([4, 5, 6, 7] if modulus == 11 else [])
        print(f"mod {modulus:3d}  {len(found):3d} attained  missing {missing}")
    assert (157 - 4) ** 2 > 144 * 157


if __name__ == "__main__":
    main()
