"""CPU-only contracts for batched preparation of original production windows."""
import hashlib
import io
import json
import os
from pathlib import Path
import sys
import subprocess
import threading
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import packed_worker as worker
import adapter_runtime as adapter
import buffered_pipeline as buffering
import coordinator_pipeline as pipeline
import runtime_initialize
import scheduling
import width_coverage as coverage

ROOT=Path(__file__).resolve().parent


class Serial:
    def __init__(self):self.calls=[]
    def map(self,function,items,chunksize):
        items=list(items);self.calls.append((function,len(items)))
        return list(map(function,items))


def signature(chunk):
    buffering.validate_cached(chunk)
    return dict(window=chunk.window.identity(),spans=chunk.window.spans,
        specifications=chunk.window.explicit_specs,patches=chunk.patches,
        certificate=chunk.plan.certificate_sha256,geometry=chunk.geometry_sha256,
        points=chunk.plan.points,packets=tuple(batch.packet for batch in chunk.plan.batches))


class PreparationUpgradeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        os.sched_setaffinity(0,{4,5})
        runtime_initialize.initialize(ROOT/'source/lattice_prototype')

    def windows(self):
        first=1538849024
        return [pipeline.Window(100000000001,200000000000,a,b,8,222,42,'adaptive')
            for a,b in [(first,first+7),(first+7,first+18),(first+18,first+21)]]

    def test_original_variable_windows_packets_and_certificates_unchanged(self):
        windows=self.windows();serial=Serial()
        singles=[buffering.prepare_cached(serial,window,4) for window in windows]
        grouped=Serial();seen=[]
        stream=scheduling.BulkStream(windows,
            lambda batch:scheduling.prepare_many(grouped,batch,4),16)
        with stream:
            for chunk in stream:
                seen.append(signature(chunk));stream.ack(chunk)
        self.assertEqual(seen,[signature(chunk) for chunk in singles])
        self.assertEqual(len(grouped.calls),1)
        self.assertEqual(len(serial.calls),3)
        self.assertEqual(stream.snapshot()['preparation_batch_windows'],16)
        self.assertEqual(stream.snapshot()['ready_limit'],1)
        self.assertEqual(stream.snapshot()['peak_reserved_bytes']<=36*1024**2,True)

    def test_guarded_subdivision_and_original_boundaries_preserved(self):
        windows=self.windows();first=windows[0].first
        original=pipeline.prepare_certified
        def guarded(spec):
            if spec[0]==first and spec[4]==coverage.edge(spec[1],first+4):
                raise pipeline.GuardedPatch('Injected guarded group subdivision')
            return original(spec)
        with patch.object(pipeline,'prepare_certified',guarded):
            singles=[buffering.prepare_cached(Serial(),window,4) for window in windows]
            batched=list(scheduling.prepare_many(Serial(),windows,4))
        self.assertEqual([signature(chunk) for chunk in singles],
                         [signature(chunk) for chunk in batched])
        self.assertEqual(batched[0].window.spans[:2],((first,first+2),(first+2,first+4)))
        for chunk,window in zip(batched,windows):
            cursor=window.first
            for left,right in chunk.window.spans:
                self.assertEqual(left,cursor);self.assertLess(left,right)
                self.assertLessEqual(right,window.last);cursor=right
            self.assertEqual(cursor,window.last)

    def test_group8_guarded_subdivision_and_exact_certificates(self):
        windows=self.windows();first=windows[1].first
        original=pipeline.prepare_certified
        def guarded(spec):
            if spec[0]==first and spec[4]==coverage.edge(spec[1],first+8):
                raise pipeline.GuardedPatch('Injected group8 guarded subdivision')
            return original(spec)
        with patch.object(pipeline,'prepare_certified',guarded):
            singles=[buffering.prepare_cached(Serial(),window,8) for window in windows]
            batched=list(scheduling.prepare_many(Serial(),windows,8))
        self.assertEqual([signature(chunk) for chunk in singles],
                         [signature(chunk) for chunk in batched])
        self.assertEqual(batched[1].window.spans[:2],((first,first+4),(first+4,first+8)))
        for chunk in batched:
            tasks=[task for batch in chunk.plan.batches for task in batch.tasks]
            self.assertEqual(len(tasks),len(chunk.window.explicit_specs))
            for task,(_,token,_) in zip(tasks,chunk.patches):
                self.assertEqual(worker.core.certify_task(task),token)

    def test_group8_positive_exact_packets_against_independent_GMP_and_brute(self):
        lo,hi,cap=136,153,708588
        windows=[pipeline.Window(lo,hi,0,8,8,222,cap,'adaptive'),
                 pipeline.Window(lo,hi,8,16,8,222,cap,'adaptive')]
        chunks=list(scheduling.prepare_many(Serial(),windows,8))
        powers=[value**5 for value in range(hi+1)]
        expected={(a,b,c,powers[a]+powers[b]-powers[c])
            for c in range(lo,hi+1) for b in range(1,c) for a in range(1,b+1)
            if abs(powers[a]+powers[b]-powers[c])<=cap}
        self.assertIn((117,144,153,708588),expected)
        observed=set()
        for window,chunk in zip(windows,chunks):
            buffering.validate_cached(chunk)
            self.assertEqual(chunk.window.identity(),window.identity())
            cursor=window.first
            for first,last in chunk.window.spans:
                self.assertEqual(first,cursor);self.assertLessEqual(last-first,8);cursor=last
            self.assertEqual(cursor,window.last)
            for batch in chunk.plan.batches:
                completed=subprocess.run([str(ROOT/'bin/gmp_reference')],input=batch.packet,
                    text=True,capture_output=True,check=True,timeout=15)
                reference=json.loads(completed.stdout)
                pipeline.validate_response_types(reference)
                self.assertTrue(reference['box_complete'])
                self.assertEqual(reference['points_visited'],sum(task.points for task in batch.tasks))
                self.assertEqual(adapter.normalized_counts(batch,reference),
                    [(task.id,task.points,task.points) for task in batch.tasks])
                observed.update(worker.core.decode_batch(batch,reference,'emulated'))
        self.assertEqual(observed,expected)

    def test_bulk_stream_rejects_changed_window_and_duplicate_ack(self):
        windows=self.windows()
        bad=SimpleNamespace(window=windows[1],payload_bytes=1,plan=SimpleNamespace(points=1))
        stream=scheduling.BulkStream([windows[0]],lambda batch:[bad],16)
        with stream,self.assertRaisesRegex(ValueError,'original window identity'):
            next(stream)
        good=SimpleNamespace(window=windows[0],payload_bytes=1,plan=SimpleNamespace(points=1))
        stream=scheduling.BulkStream([windows[0]],lambda batch:[good],16)
        with stream:
            chunk=next(stream);stream.ack(chunk)
            with self.assertRaisesRegex(ValueError,'release'):stream.ack(chunk)

    def test_configured_production_window_size_is_preserved(self):
        config=dict(initial_patch=100,shell_lo=10,shell_hi=20,chunk_patches=37,
                    width=8,bits=222,cap=42,geometry_policy='adaptive')
        windows=list(worker.windows(config,180))
        self.assertEqual([(w.first,w.last) for w in windows],[(100,137),(137,174),(174,180)])

    def test_cpu_map_stop_guard_and_explicit_gpu_callback(self):
        pool=SimpleNamespace(_pool=[])
        gpu=SimpleNamespace()
        observed=[]
        def dispatch(actual_pool,arguments,check):
            self.assertIs(actual_pool,pool);check();observed.extend(arguments)
            return ['sentinel-only']
        gpu.dispatch=dispatch
        live=worker.LivePool(pool,{},ROOT,threading.Event(),gpu)
        with patch.object(worker.policy,'remaining',side_effect=worker.policy.RequestedStop('test stop')):
            with self.assertRaises(worker.policy.RequestedStop):
                live.map(coverage.prepare_segment,[('unused',)],1)
        self.assertEqual(observed,[])
        with patch.object(worker.policy,'remaining',return_value=30) as guard:
            self.assertEqual(live.map(coverage.prepare_segment,[('unchanged',)],1),['sentinel-only'])
            guard.assert_called_once()
        self.assertEqual(observed,[('unchanged',)])


def main():
    log=io.StringIO()
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(PreparationUpgradeTests)
    result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
    evidence=ROOT.parent.parent/'evidence';evidence.mkdir(parents=True,exist_ok=True)
    report=dict(status='passed' if result.wasSuccessful() else 'failed',TEST_ONLY=True,
        GPU_used=False,production_modified=False,production_restarted=False,
        tests_run=result.testsRun,failures=len(result.failures),errors=len(result.errors),
        command=[sys.executable,str(Path(__file__).resolve())],unittest_log=log.getvalue(),
        files_sha256={name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
            for name in ('packed_worker.py','scheduling.py','buffered_pipeline.py','width_coverage.py',
                         'gpu_preparation.py','test_preparation_upgrade.py')})
    (evidence/'preparation-upgrade-contracts.json').write_text(json.dumps(report,indent=2)+'\n')
    print(log.getvalue(),end='')
    return 0 if result.wasSuccessful() else 1


if __name__=='__main__':raise SystemExit(main())
