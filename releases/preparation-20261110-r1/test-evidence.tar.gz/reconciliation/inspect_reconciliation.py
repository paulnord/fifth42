"""Read-only production snapshot; writes review evidence only, never locks."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import time

HERE = Path(__file__).resolve().parent
PRODUCTION = Path('/home/pnord/scratch/cabbage-extended-20261109')
EXPECTED_CURSOR = 1538849024
EXPECTED_CHECKPOINT = 'fe45bc2d74fe90ea2c542ac6e3423967d8f7e65c756c9406379482fe2a3db5cc'


def read(path):
    return json.loads(Path(path).read_bytes())


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(4 * 1024**2), b''):
            h.update(block)
    return h.hexdigest()


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def command(arguments):
    result = subprocess.run(arguments, text=True, capture_output=True, timeout=15)
    return dict(arguments=arguments, returncode=result.returncode,
                stdout=result.stdout, stderr=result.stderr)


def journal_edges(path):
    stat = path.stat()
    with path.open('rb') as stream:
        first = stream.readline(1024**2)
        stream.seek(max(0, stat.st_size - 1024**2))
        tail = stream.read()
    require(tail.endswith(b'\n'), f'Partial journal suffix {path}')
    last = tail.splitlines()[-1]
    return dict(path=str(path), bytes=stat.st_size, device=stat.st_dev,
                inode=stat.st_ino, mtime_ns=stat.st_mtime_ns,
                first=json.loads(first), last=json.loads(last),
                first_line_sha256=hashlib.sha256(first).hexdigest(),
                last_line_sha256=hashlib.sha256(last + b'\n').hexdigest())


binding = read(PRODUCTION / 'active-configuration.json')
config_path = Path(binding['config'])
config = read(config_path)
run = Path(config['output'])
replica = Path(config['replica_output'])
cp = read(run / 'checkpoint.json')
status = read(run / 'status.json')
supervisor = read(run.parent / 'supervisor.json')
final = read(run / 'final-replica.json')
replica_state = read(replica / 'replica-state.json')
controller = read(PRODUCTION / 'controller-state.json')
claim_path = Path(config['origin_claim_file'])
claim = read(claim_path)
ledger = Path(config['ledger_root'])
reservations_path = ledger / 'reservations.jsonl'
reservation_raw = reservations_path.read_bytes()
require(reservation_raw.endswith(b'\n'), 'Reservation log has a partial suffix')
reservations = [json.loads(line) for line in reservation_raw.splitlines()]
for row in reservations:
    payload = {key: value for key, value in row.items() if key != 'sha256'}
    hashed = hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    require(hashed == row['sha256'], f"Invalid reservation digest {row['job']}")
sorted_reservations = sorted(reservations, key=lambda row: row['first'])
for left, right in zip(sorted_reservations, sorted_reservations[1:]):
    require(left['last'] <= right['first'], 'Top-level reservation overlap')
require([row for row in reservations if row['job'] == config['ledger_job']] == [claim],
        'Actual ledger claim differs from pinned original')
require(sha(config_path) == binding['config_sha256'], 'Active configuration hash mismatch')
require(sha(config['manifest']) == binding['manifest_sha256'] == config['manifest_sha256'],
        'Release manifest identity mismatch')
require(sha(run / 'checkpoint.json') == EXPECTED_CHECKPOINT, 'Unexpected final checkpoint hash')
require(cp['next_patch'] == EXPECTED_CURSOR, 'Unexpected final cursor')
require((run / 'checkpoint.json').read_bytes() == (replica / 'checkpoint.json').read_bytes(),
        'Replica checkpoint differs from local checkpoint')
require(status['status'] == 'stopped' and status['error'] is None and
        status['journal_buffer']['pending_chunks'] == status['journal_buffer']['pending_bytes'] == 0,
        'Worker did not stop cleanly and flush')
require(supervisor['worker_exit_code'] == 0 and supervisor['leases_released'] is True and
        supervisor['error'] is None, 'Supervisor did not finish cleanly')
require(final['status'] == final['receipt']['status'] == 'verified', 'Final replica not verified')
require(final['receipt'] == replica_state, 'Local and bulk replica receipts differ')
require(final['receipt']['checkpoint_sha256'] == EXPECTED_CHECKPOINT and
        final['receipt']['next_patch'] == cp['next_patch'] and
        final['receipt']['committed_bytes'] == cp['journal_offset'] and
        final['receipt']['journal_sha256'] == cp['journal_sha256'] and
        final['receipt']['identity'] == cp['identity'], 'Final replica provenance mismatch')
edges = [journal_edges(path) for path in (run / 'coverage.jsonl', replica / 'coverage.jsonl')]
for edge in edges:
    require(edge['bytes'] == cp['journal_offset'], 'Journal has trailing or missing bytes')
    require(edge['first']['sequence'] == 1 and
            edge['first']['window']['first'] == config['initial_patch'], 'Journal start mismatch')
    require(edge['last']['sequence'] == cp['chunks'] and
            edge['last']['window']['last'] == cp['next_patch'] and
            edge['last']['sha256'] == cp['journal_sha256'], 'Journal final receipt mismatch')
require(edges[0]['first_line_sha256'] == edges[1]['first_line_sha256'] and
        edges[0]['last_line_sha256'] == edges[1]['last_line_sha256'], 'Journal endpoint bytes differ')
for edge in edges:
    edge['first'] = {key: edge['first'][key] for key in ('sequence', 'window', 'sha256')}
    edge['last'] = {key: edge['last'][key] for key in ('sequence', 'window', 'sha256')}

manifest = read(config['manifest'])
manifest_root = Path(config['manifest']).parent
source_mismatches = [name for name, digest in manifest['files'].items()
                     if sha(manifest_root / name) != digest]
require(not source_mismatches, f'Frozen production source changed: {source_mismatches}')
metadata_paths = [
    PRODUCTION / 'active-configuration.json', PRODUCTION / 'controller-state.json',
    PRODUCTION / 'controller.stderr.log', PRODUCTION / 'controller.py',
    PRODUCTION / 'controller-manifest.json', PRODUCTION / 'collector-settings.json',
    PRODUCTION / 'HANDOFF.txt', PRODUCTION / 'release.py', PRODUCTION / 'units.py',
    PRODUCTION / 'stop_controller.py', PRODUCTION / 'seal_previous.py',
    config_path, Path(config['manifest']), claim_path, Path(config['coverage_file']),
    run / 'checkpoint.json', run / 'status.json', run / 'final-replica.json',
    run / 'replication-health.json', run.parent / 'supervisor.json',
    replica / 'checkpoint.json', replica / 'replica-state.json', reservations_path,
    Path('/mnt/nfs_share/cabbage-extended-publishing-20261109/active-publication-spec.json'),
]
file_identities = {str(path): dict(bytes=path.stat().st_size, sha256=sha(path))
                   for path in metadata_paths}
resources = {str(path): dict(free_bytes=shutil.disk_usage(path).free,
                             device=path.stat().st_dev)
             for path in (Path('/home/pnord/fifth42-local-runs'),
                          Path('/mnt/fifth42-storage'), ledger)}
service_names = [config['service_name'], config['cleanup_service_name'],
                 config['deadline_service_name'].replace('.service', '.timer'),
                 'cabbage-extended-controller-20261109.service',
                 'cabbage-extended-controller-20261109-deadline.timer',
                 'cabbage-extended-collector-20261109.service']
units = command(['systemctl', '--user', 'show', *service_names,
                 '--property=Id,ActiveState,SubState,MainPID,Result,ExecMainStatus,NextElapseUSecRealtime'])
gpu = command(['nvidia-smi', '--query-compute-apps=pid,process_name', '--format=csv,noheader'])
mounts = [command(['findmnt', '-n', '-o', 'TARGET,SOURCE,FSTYPE,OPTIONS', '-T', str(path)])
          for path in (run, replica, ledger)]
captured = datetime.now(timezone.utc).isoformat()

report = dict(
    status='read_only_reconciliation_passed_pending_full_seal_and_parent_launch_decision',
    captured_utc=captured, production_modified=False, locks_acquired=False,
    source_path=str(PRODUCTION), active_config=str(config_path),
    file_identities=file_identities,
    frontier=dict(
        authoritative_committed_cursor=EXPECTED_CURSOR, checkpoint_sha256=EXPECTED_CHECKPOINT,
        original_claim=[claim['first'], claim['last']],
        current_run_selected=[config['initial_patch'], cp['next_patch']],
        combined_allocation_selected=[claim['first'], cp['next_patch']],
        restart_interval=[cp['next_patch'], claim['last']],
        remaining_logical_cells=claim['last'] - cp['next_patch'],
        ledger_job=config['ledger_job'], ledger_claim_sha256=claim['sha256'],
        reservation_identity=claim['identity'],
        ownership_lock=str(ledger / 'jobs' / config['ledger_job'] / 'journal.jsonl'),
        ownership_journal_bytes=(ledger / 'jobs' / config['ledger_job'] / 'journal.jsonl').stat().st_size,
        ownership_journal_note='Stable NFS owner lock only for this local-journal architecture; zero bytes do not negate local/bulk coverage. Never use generic Store.recover to choose the resume frontier.',
        zero_patch='Outside this reservation; unresolved historical boundary; never claim complete whole-shell coverage.',
    ),
    checkpoint=cp, stopped_worker=status, supervisor=supervisor,
    final_copy=dict(local_receipt=final, bulk_receipt=replica_state,
                    byte_identical_local_and_bulk_checkpoint=True,
                    local_and_bulk_journal_endpoint_bytes_equal=True,
                    journal_edges=edges,
                    full_raw_sha256_receipted=final['receipt']['raw_sha256'],
                    full_raw_sha256_recomputed_in_this_review=False,
                    full_audit_required_before_new_source_lineage=True),
    controller=dict(
        current_state=controller,
        diagnosis='Controller observed compute service inactive and indexed supervisor worker_exit_code before the supervisor finished writing its terminal cleanup report.',
        controller_failed_utc=datetime.fromtimestamp(controller['updated_epoch'], timezone.utc).isoformat(),
        supervisor_finished_utc=supervisor['updated_utc'],
        worker_report_is_now_complete_and_clean=True,
        history_missing_final_clean_run=True,
        restart_old_controller_unsafe='main() always begins from ROOT/production-config.json and start() forbids existing output reuse; original frozen deadline is also embedded in controller/release/policy. Reset-failed alone does not reconcile it.',
        required_fix='In a fresh frozen controller, wait boundedly for terminal supervisor status, explicit worker_exit_code=0 and leases_released=true; then verify checkpoint/final replica. A stopped/manual parent must never trigger automatic retry.',
    ),
    deadline=dict(
        active_epoch=config['stop_epoch'], active_local=config['stop_local'],
        global_handoff=str(PRODUCTION / 'HANDOFF.txt'),
        handoff_request_date='2026-11-09', handoff_explicit_deadline='2026-11-10 17:00 America/Chicago',
        independent_compute_stop_begins_epoch=config['stop_epoch'] - 10,
        november_11_epoch=1794438000,
        interpretation='Current files support Nov10 17:00. A Nov11 extension must be an explicit parent decision based on latest user authorization; this reviewer did not infer or apply it.',
        update_if_extended='Controller and release constants, frozen worker policy/base configuration, production configuration, global/per-run timers and runtime bounds, collector settings/publication binding must all agree. Retire any old global timer that follows the active pointer or it can stop the new run early.',
    ),
    guards=dict(
        physical_cpus=config['physical_cpus'], workers=config['workers'],
        shell=[config['shell_lo'], config['shell_hi']], cap=config['cap'], bits=config['bits'],
        width=config['width'], logical_chunk_cells=config['chunk_patches'],
        group_limit=config['group_limit'], dispatch_chunksize=config['dispatch_chunksize'],
        exact_gmp_audit_period=config['gmp_audit_period'],
        replica_interval_seconds=config['replica_interval_seconds'],
        maximum_replica_lag_seconds=config['maximum_replica_lag_seconds'],
        journal_limit_bytes=config['journal_limit_bytes'],
        minimum_free_disk_bytes=config['minimum_free_disk_bytes'],
        startup_local_free_required=config['journal_limit_bytes'] + config['minimum_free_disk_bytes'],
        prep_load_ceiling=config['prep_load_ceiling'], running_load_limit=config['running_load_limit'],
        journal_buffer_records=config['journal_buffer_records'],
        journal_buffer_bytes=config['journal_buffer_bytes'],
        journal_buffer_max_age_seconds=config['journal_buffer_max_age_seconds'],
        host_gpu_lock='/home/pnord/scratch/saved-root-readiness-Ija5nMHk/cabbage-runtime/gpu-owner.lock',
        ownership_and_gpu_lock_acquisition_not_tested_in_this_review=True,
        original_frozen_sources_match_release_manifest=True,
        original_policy_integration_changes_needed='Current policy accepts group_limit 1/2/4, preparation_windows=1, ready_limit=3, request_windows=1. Batched preparation/GPU proposals require an explicitly tested frozen policy and worker update; keep native requests and journals at 256 logical cells.',
        freeze_source_trap='release.freeze copies old ROOT/worker unless a tested worker is prepopulated. Verify the final source archive matches actual tested GPU-stage/kernel/certifier/buffering files; never copy old runtime over the tested code.',
        run_id_prefix='Current policy requires production run_id to start cabbage-extended-. Fresh output and replica directories must not exist at worker startup.',
    ),
    reservations=dict(
        stable_file_sha256=sha(reservations_path), digest_and_nonoverlap_checks_passed=True,
        rows=[{key: row[key] for key in ('job', 'first', 'last', 'identity', 'sha256')}
              for row in sorted_reservations],
        current_claim_unchanged=True,
        unrelated_suballocation_parent='Ada/Boole suballocation belongs to [3917103232,11250000001), outside Cabbage claim; no Cabbage overlap.',
        note='Reservation ownership is not a completed-coverage frontier. No ledger append/reservation change is needed to continue the existing Cabbage interval.',
    ),
    resources=resources, systemd_snapshot=units, gpu_snapshot=gpu, mounts=mounts,
    recommended_parent_sequence=[
        'Preserve this stopped run, failed controller state/stderr, original claim and metadata snapshots. Do not edit the old journal/checkpoint or restart the old controller.',
        'Choose a deadline using the latest actual user authorization; keep Nov10 17:00 unless a later extension is established. Ensure every new independent timer and frozen policy agrees.',
        'When GPU is quiescent, use the existing seal_previous.py with this exact active config and a fresh evidence path. It acquires original NFS owner and GPU locks, audits all 166706 committed receipts and 1303 saved GMP checks, recomputes local+bulk raw SHA256, and retains a read-only archive. Expect checkpoint fe45bc2d… and cursor1538849024.',
        'Freeze a fresh, separately identified continuation from the resulting parent-seal, retaining original job/claim/identity and interval [1538849024,2250000000). Set parent-selected logical cells=1038849024, not just the last journal count42676736. Preserve original claim proof bytes.',
        'Use the tested runtime source in a fresh worker tree; update frozen policy only for intended batching/preparation changes and approved deadline. Native packet, exact certificate, residual, GMP cadence, local durable journal, NFS owner lock and replica guards remain mandatory.',
        'Run bounded actual-release nonempty/full-oracle, GMP, corrupted-proposal fallback, partial-window, graceful stop, replication and deadline checks against fresh TEST_ONLY outputs. Never test by recovering the production journal.',
        'Install a fresh controller/compute/final-copy service set with Restart=no, 16 physical workers, stable original NFS ownership lock, stable host GPU lock, fresh local/replica paths, independent absolute stop and final-copy cleanup. Use bounded supervisor-terminal wait to avoid the observed race.',
        'Replace or disable old global stop timer/collector bindings only as part of the authorized upgrade, after the new configuration is frozen; the old global stop helper follows active-configuration.json and can stop a new run.',
        'Publish new source/config/archive hashes and parent reconciliation/seal evidence with READY written last; bind reporting to the new run. Start once, verify real committed cursor movement, exact controls, worker affinities, held locks, replica catch-up and surviving services/linger before declaring logout safe.',
        'At stop, finish final local durable commit, drain/terminate compute, wait for terminal supervisor report and verified final bulk replica. Do not mark the reservation complete or allocate overlapping work from reservation metadata alone.',
    ],
    suggested_seal_command=[
        '/home/pnord/scratch/saved-root-pAjTHBhR/venv/bin/python', '-B',
        str(PRODUCTION / 'seal_previous.py'), '--config', str(config_path),
        '--evidence', str(HERE / 'final-parent-seal'),
    ],
    limitations=[
        'This review reads metadata and journal endpoints; it does not rerun the complete 2.99GB scientific receipt audit or rehash both full journals. Existing verified final-copy receipt is consistent; full sealing is still required before a new source lineage.',
        'No ledger or GPU lock was acquired; clean supervisor status and current process/service snapshots are evidence of quiescence, not a substitute for exclusive lock acquisition immediately before upgrade.',
        'Collector publication status refreshes periodically and is derivative. Checkpoint/final replica bytes and original ledger claim are the authoritative inputs.',
    ],
)
HERE.mkdir(parents=True, exist_ok=True)
(HERE / 'RECONCILIATION.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
(HERE / 'RECONCILIATION.md').write_text(
    '# Cabbage read-only reconciliation\n\n'
    f'Captured {captured}. Production remains stopped and unchanged.\n\n'
    f'Resume frontier: **{EXPECTED_CURSOR}**; checkpoint SHA256 `{EXPECTED_CHECKPOINT}`. '
    f'Local and verified bulk checkpoint bytes agree. Remaining owned interval '
    f'`[{EXPECTED_CURSOR},2250000000)` contains {2250000000 - EXPECTED_CURSOR} logical cells.\n\n'
    'The last worker stopped cleanly, flushed pending records, returned exit code 0 and released its leases. '
    'The controller failed about three seconds before the supervisor wrote its final report, while indexing '
    '`worker_exit_code`; its failed state is a reporting/lifecycle race, and its history omits this last run.\n\n'
    'Current immutable config, controller constants, collector and timers all say **Nov10 17:00 Central**, '
    'with compute stop beginning 16:59:50. The extension handoff explicitly dates the request Nov9. '
    'A Nov11 deadline requires a separate parent decision and consistent updates to every timer/policy.\n\n'
    'The NFS ownership journal is deliberately empty. Do not recover from it or rewind to500000000; '
    'preserve the existing claim and use the verified local/bulk frontier.\n\n'
    'Before starting a new source lineage, run the full stopped-parent seal with exclusive owner/GPU locks. '
    'This review checked metadata, file identities and journal endpoints; it did not duplicate the2.99GB full audit. '
    'Never restart the old controller directly.\n\n'
    'See RECONCILIATION.json for exact paths/hashes, resources, constraints, commands and the ordered launch plan.\n'
)
print(json.dumps(dict(status=report['status'], report=str(HERE / 'RECONCILIATION.json'),
                     cursor=EXPECTED_CURSOR, checkpoint_sha256=EXPECTED_CHECKPOINT,
                     local_free_bytes=resources['/home/pnord/fifth42-local-runs']['free_bytes']), indent=2))
