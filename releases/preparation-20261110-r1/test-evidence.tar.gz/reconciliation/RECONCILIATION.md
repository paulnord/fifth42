# Cabbage read-only reconciliation

Captured 2026-11-10T19:36:46.760085+00:00. Production remains stopped and unchanged.

Resume frontier: **1538849024**; checkpoint SHA256 `fe45bc2d74fe90ea2c542ac6e3423967d8f7e65c756c9406379482fe2a3db5cc`. Local and verified bulk checkpoint bytes agree. Remaining owned interval `[1538849024,2250000000)` contains 711150976 logical cells.

The last worker stopped cleanly, flushed pending records, returned exit code 0 and released its leases. The controller failed about three seconds before the supervisor wrote its final report, while indexing `worker_exit_code`; its failed state is a reporting/lifecycle race, and its history omits this last run.

Current immutable config, controller constants, collector and timers all say **Nov10 17:00 Central**, with compute stop beginning 16:59:50. The extension handoff explicitly dates the request Nov9. A Nov11 deadline requires a separate parent decision and consistent updates to every timer/policy.

The NFS ownership journal is deliberately empty. Do not recover from it or rewind to500000000; preserve the existing claim and use the verified local/bulk frontier.

Before starting a new source lineage, run the full stopped-parent seal with exclusive owner/GPU locks. This review checked metadata, file identities and journal endpoints; it did not duplicate the2.99GB full audit. Never restart the old controller directly.

See RECONCILIATION.json for exact paths/hashes, resources, constraints, commands and the ordered launch plan.
