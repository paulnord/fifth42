"""Exact bounded tests for the two-file production-targeted root-reuse patch."""
import dataclasses
import difflib
from fractions import Fraction
import importlib.util
from pathlib import Path
import random
import sys
import unittest

import gmpy2

ROOT = Path(__file__).resolve().parent
GPU = ROOT/'baseline/source/lattice_gpu'
sys.path.insert(0,str(GPU))
import packing_opt
import precision_policy

def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    result=importlib.util.module_from_spec(spec);sys.modules[name]=result
    spec.loader.exec_module(result);return result

def engine(variant,kind='mpq'):
    result=module(f'_{variant}_{kind}_{len(sys.modules)}', ROOT/variant/'source/lattice_prototype/compiled_experiment/lattice5_snapshot.py')
    result.Q=gmpy2.mpq if kind=='mpq' else Fraction
    return result

def core(lattice):
    result=module(lattice.__name__+'_core',GPU/'scaling_core.py')
    result._ENGINE=('isolated_test',lattice);result.MAX_BOUND=200000000000
    return result

class RootReuseTests(unittest.TestCase):
    def test_patch_targets_identical_and_only_intended_change(self):
        for variant in ('baseline','candidate'):
            a=ROOT/variant/'source/lattice_prototype/lattice5.py'
            b=ROOT/variant/'source/lattice_prototype/compiled_experiment/lattice5_snapshot.py'
            self.assertEqual(a.read_bytes(),b.read_bytes())
        original=engine('baseline');patched=engine('candidate')
        self.assertEqual(original.root_bracket.__code__.co_code,patched.root_bracket.__code__.co_code)
        self.assertEqual(original.iroot.__code__.co_code,patched.iroot.__code__.co_code)
        allowed={'lattice_prototype/lattice5.py','lattice_prototype/compiled_experiment/lattice5_snapshot.py'}
        diff=[]
        for path in sorted((ROOT/'baseline/source').rglob('*.py')):
            relative=path.relative_to(ROOT/'baseline/source')
            revised=ROOT/'candidate/source'/relative
            if str(relative) in allowed:
                diff.extend(difflib.unified_diff(path.read_text().splitlines(keepends=True),revised.read_text().splitlines(keepends=True),
                    fromfile='a/source/'+str(relative),tofile='b/source/'+str(relative)))
            else:self.assertEqual(path.read_bytes(),revised.read_bytes(),str(relative))
        # The patch artifact and tested source differences must be identical.
        expected=(ROOT/'reuse-exact-lower-root.patch').read_text()
        pieces=expected.split('--- a/source/')
        ordered=''.join('--- a/source/'+s for s in sorted(pieces[1:],key=lambda s:s.splitlines()[0]))
        self.assertEqual(''.join(diff),ordered)

    def test_exact_dyadic_boundary_and_fallback_proof(self):
        rng=random.Random(20261108)
        for kind in ('fraction','mpq'):
            e=engine('baseline',kind);Q=e.Q
            for bits in (1,2,8,48,88,222):
                d=1<<bits
                for n in (1,max(1,d//3),d-1,d,d+1):
                    low=Q(n,d);boundary=low**5
                    x=(boundary+Q(n+1,d)**5)/2
                    self.assertEqual(e.root_bracket(x,bits)[0],low)
                    for y in (boundary,boundary+Q(1,1<<(5*bits+4)),boundary-Q(1,1<<(5*bits+4))):
                        if y<0 or y>x:continue
                        obtained=low if low**5<=y else e.root_bracket(y,bits)[0]
                        self.assertEqual(obtained,e.root_bracket(y,bits)[0])
                        if y<boundary:self.assertLess(obtained,low)
            for _ in range(2000):
                bits=rng.randrange(1,225);x=Q(rng.randrange(1,10**12),10**12)
                y=x*Q(rng.randrange(10**8+1),10**8)
                low=e.root_bracket(x,bits)[0]
                obtained=low if low**5<=y else e.root_bracket(y,bits)[0]
                self.assertEqual(obtained,e.root_bracket(y,bits)[0])

    def test_exact_patch_fields_and_bases_at_low_high_boundary_inputs(self):
        rng=random.Random(10842)
        for kind in ('fraction','mpq'):
            a,b=engine('baseline',kind),engine('candidate',kind);Q=a.Q
            lo,hi=100000000001,200000000000;count=(9*lo+79)//80
            ids=sorted(set([0,1,2,3000000000,3917103232,6250000000,10625000000,count-1]+[rng.randrange(count) for _ in range(80)]))
            args=[]
            for i in ids:
                left,right=Q(9*i,10*count),Q(9*(i+1),10*count)
                for bits in (48,88,222,precision_policy.geometry_bits(a,lo,hi,left,right,42)):
                    args.append((lo,hi,left,right,42,bits))
            args += [(1,2,Q(0),Q(1,2),0,48),(16,31,Q(7,10),Q(4,5),384,48),
                     (64,100,Q(1,2),Q(3,5),2951,48),
                     (lo,hi,Q(1,2),Q(500000000001,10**12),10**45,88)]
            for row in args:
                x,y=a.make_patch(*row),b.make_patch(*row)
                self.assertEqual(dataclasses.asdict(x),dataclasses.asdict(y))
                self.assertEqual(x.basis(),y.basis())

    def test_call_count_reuses_one_root_and_falls_back(self):
        e=engine('candidate');Q=e.Q;lo=100000000001;hi=200000000000
        count=(9*lo+79)//80;i=3917103232
        left,right=Q(9*i,10*count),Q(9*(i+1),10*count)
        original=e.root_bracket;calls=[]
        def counted(*args):calls.append(args);return original(*args)
        e.root_bracket=counted
        e.make_patch(lo,hi,left,right,42,88);self.assertEqual(len(calls),2)
        calls.clear();e.make_patch(lo,hi,left,right,42,222);self.assertEqual(len(calls),3)
        calls.clear();e.make_patch(lo,hi,left,right,0,88);self.assertEqual(len(calls),2)

    def test_failure_behavior_preserved(self):
        a,b=engine('baseline'),engine('candidate');Q=a.Q
        inputs=[(0,1,Q(0),Q(1,2),42,48),(2,1,Q(0),Q(1,2),42,48),
                (1,2,Q(-1),Q(1,2),42,48),(1,2,Q(1,2),Q(1,2),42,48),
                (1,2,Q(0),Q(1),42,48),(1,2,Q(0),Q(1,2),-1,48),
                (1,2,Q(0),Q(1,2),42,48),(1,2,Q(0),Q(1,2),0,0),
                (1,2,Q(0),Q(999,1000),0,1)]
        for args in inputs:
            errors=[]
            for e in (a,b):
                try:e.make_patch(*args)
                except Exception as ex:errors.append((type(ex),str(ex)))
                else:self.fail('Expected rejection')
            self.assertEqual(errors[0],errors[1])

    def test_tasks_certificates_payloads_packets_and_tamper_checks(self):
        a,b=engine('baseline'),engine('candidate');ca,cb=core(a),core(b)
        lo,hi=100000000001,200000000000;count=(9*lo+79)//80
        accepted=rejected=0
        for i in (1,3000000000,3917103232,6250000000,10625000000,count-1):
            left,right=(9*i,10*count),(9*(i+1),10*count)
            bits=precision_policy.geometry_bits(a,lo,hi,a.Q(*left),a.Q(*right),42)
            spec=(i,lo,hi,left,right,42,bits)
            x,y=ca.prepare_task(spec),cb.prepare_task(spec)
            self.assertEqual(vars(x),vars(y))
            try:token=ca.certify_task(x)
            except ValueError as error:
                with self.assertRaisesRegex(ValueError,str(error)):cb.certify_task(y)
                rejected+=1
                continue
            accepted+=1
            self.assertEqual(token,cb.certify_task(y))
            self.assertEqual(packing_opt.task_payload(x),packing_opt.task_payload(y))
            self.assertEqual(ca.encode_batch([x],42).packet,cb.encode_batch([y],42).packet)
            for bad in (dataclasses.replace(y,J=(y.J[0]+1,*y.J[1:])),dataclasses.replace(y,points=y.points+1),
                        dataclasses.replace(y,bits=y.bits+8),dataclasses.replace(y,U=((0,0,0),*y.U[1:]))):
                with self.assertRaises(ValueError):cb.certify_task(bad)
        self.assertEqual(accepted,5)
        self.assertEqual(rejected,1)

if __name__=='__main__':unittest.main(verbosity=2)
