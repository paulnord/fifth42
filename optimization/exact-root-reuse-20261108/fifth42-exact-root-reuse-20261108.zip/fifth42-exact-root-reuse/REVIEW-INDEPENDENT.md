# Independent review: exact lower-root reuse

Verdict: no correctness defect found in the two-source-file patch. Suitable for continued isolated performance evaluation; not yet a validated production release or evidence of GPU throughput improvement.

## Exact argument

Let d = 2**bits, x = 1-right**5, y = x-eta, and vlo = n/d returned by root_bracket(x,bits). Existing guards establish eta >= 0 and y > 0. The integer-root construction establishes vlo**5 <= x < ((n+1)/d)**5, including when x itself is a perfect fifth power. If vlo**5 <= y, then vlo**5 <= y <= x < ((n+1)/d)**5, so root_bracket(y,bits)[0] is exactly vlo. Otherwise the original calculation runs. Equality at y = vlo**5 must reuse, and the <= predicate handles it correctly. This is equality of dyadic floors, not an approximation to a root.

Both supported arithmetic modes, Fraction and gmpy2.mpq, evaluate these powers and comparisons exactly. No float is introduced. eta=0, a downward dyadic boundary crossing, zero floor at insufficient precision, invalid bits, and the singular-region/domain guards preserve the original result or rejection. The earlier root calls validate bits even when the final call is skipped. The discarded upper root is not consumed downstream. Patch fields, basis, and certification remain unchanged; certification rebuilds its patch instead of trusting prepared geometry. The proof depends on the supported exact rational arithmetic and the existing floor-root contract, not arbitrary monkey-patched approximate root routines.

## Evidence checked

- Independently recomputed Git blob SHA-1 identities for all 124 local baseline files against upstream-files.json at commit da4e1e312ce1558c9d8cf027c009f8b400f22b83. This verifies consistency with the recorded upstream manifest; no independent remote fetch was performed in this review.
- Compared baseline/candidate source trees: the implementation changes are the two intended identical make_patch edits. Generated test/build artifacts are separate from implementation scope.
- Read test_root_reuse.py and its successful six-test log. Coverage includes both arithmetic modes, 4,000 deterministic random root pairs, exact dyadic boundaries, full patch fields/bases, both branch call counts, failure parity, task/certificate/payload/packet equality, and certificate tampering rejection.
- Compared all 16 case records in validation-baseline.json and validation-candidate.json: identical. Reviewed run_probe.py: native CPU plus UBSan cases have independent GMP count/full-record checks and nonempty independent small-domain hit oracles, plus bounded large-domain samples.
- Read successful upstream logs: 107 GPU-package tests, 24 lattice tests, five mpq tests. These are recorded test results, not independent reruns by this reviewer. No heavy benchmarks were launched.

## Integration and limitations

1. Addressed during packaging: the initial scratch candidate inherited stale baseline release hashes. The historical manifest is now renamed UPSTREAM_RELEASE_MANIFEST_REFERENCE.json, verified byte-identical to the baseline manifest. CANDIDATE-SOURCE-MANIFEST.json explicitly marks the candidate scratch-only and non-deployable; this reviewer verified its 132 file hashes. The distributed package contains baseline plus patch, not a ready deployment, and reproduce.sh reconstructs a fresh candidate and renames the historical release manifest. README correctly distinguishes historical evidence from candidate authentication. Any later production release still needs refreshed source/binary identities and normal guards and acceptance tests. Do not bypass identity checks merely because mathematical output is equivalent.
2. Patch both the authoring source and compiled-experiment snapshot, as done here. The normal scaling_core initializer loads benchmark_mpq.py and its snapshot. Existing processes cache their engine, so copying files is not a safe hot deployment strategy. A later authorized deployment needs a fresh, verified process lifecycle.
3. The performance harness uses CPU emulation, local storage and a small cloud CPU allocation. Its journal recovery and result equality checks are useful, but do not demonstrate Ada CUDA throughput, NFS behavior, supervisor/publisher correctness or production coverage. Retain these exclusions in any result summary.
4. Fallback pays an extra rational power/comparison and still computes the root. Performance must be assessed at the actual adaptive precision and representative regions, with repeated alternating baseline/candidate trials. A high-precision fallback-only workload could regress. A one-third reduction in root call count on the reuse branch is not a one-third end-to-end speedup.
5. Addressed during packaging: the source-diff test now compares every baseline Python source against its candidate counterpart and requires the two permitted edits to match the distributed patch exactly. This is materially stronger than the earlier bytecode-only checks. It does not purport to detect arbitrary added candidate-only files or changes to non-Python files; the candidate source manifest and package hashes provide the broader artifact identity checks.

No remote publication, live environment changes, or implementation edits were performed by this reviewer.

## Final lightweight packaging review

Read package/README.md, reproduce.sh, and the strengthened test. Shell syntax validation passed. Packaged patch/test/probe match the reviewed working files. The reproduction flow requires a new absolute scratch directory, verifies package hashes and installed pins, applies the patch, builds local CPU tools, runs validation and regressions, and makes timing optional. No heavy rerun was performed during this final review, and successful completion of the separate reproduction run is not asserted here.

README appropriately reports modest CPU throughput ratios, the outlier and high-enumeration limitation, and explicitly excludes CUDA/NFS/production coverage claims. No new correctness or packaging blocker found. After copying this updated review into the package, regenerate PACKAGE_SHA256SUMS and any archive hashes so they cover the final review text.
