"""Exclusive alternating bounded trials of the isolated local CPU pipeline."""
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent
run=ROOT/'paired-trials'
run.mkdir(exist_ok=False)
cases=[('boole',3000000000,4096),('ada',3917103232,4096),('higher_cost',10625000000,1024)]
rows=[];began=time.monotonic()
for case,first,patches in cases:
    for repeat in range(5):
        variants=('baseline','candidate') if repeat%2==0 else ('candidate','baseline')
        pair=[]
        for variant in variants:
            out=run/f'{case}-{repeat}-{variant}'
            proc=subprocess.run([sys.executable,str(ROOT/'run_probe.py'),'benchmark','--first',str(first),'--patches',str(patches),'--output',str(out)],
                env=dict(os.environ,ROOT_REUSE_VARIANT=variant),capture_output=True,text=True,timeout=140)
            (run/(out.name+'.stdout.log')).write_text(proc.stdout)
            (run/(out.name+'.stderr.log')).write_text(proc.stderr)
            if proc.returncode:raise RuntimeError(proc.stderr)
            result=json.loads((out/'result.json').read_text());result.update(case=case,repeat=repeat)
            rows.append(result);pair.append(result)
            print(json.dumps(dict(case=case,repeat=repeat,variant=variant,seconds=result['steady_seconds'])),flush=True)
        if pair[0]['signatures_sha256']!=pair[1]['signatures_sha256'] or pair[0]['points']!=pair[1]['points'] or pair[0]['exact_hits']!=pair[1]['exact_hits']:
            raise ValueError('Paired exact geometry/packet/hit mismatch')
        (ROOT/'benchmark-progress.json').write_text(json.dumps({'completed_trials':len(rows),'elapsed_seconds':time.monotonic()-began},indent=2)+'\n')
summary=[]
for case,first,patches in cases:
    r={v:[x for x in rows if x['case']==case and x['variant']==v] for v in ('baseline','candidate')}
    med={v:statistics.median(x['steady_seconds'] for x in z) for v,z in r.items()}
    worker={v:statistics.median(sum(t[1]+t[3] for rr in x['rows'] for t in rr['worker_seconds']) for x in z) for v,z in r.items()}
    ratios=[]
    for i in range(5):
        a=next(x for x in r['baseline'] if x['repeat']==i)
        b=next(x for x in r['candidate'] if x['repeat']==i)
        ratios.append(a['steady_seconds']/b['steady_seconds'])
    summary.append(dict(case=case,first=first,patches=patches,medians=med,
        samples={v:[x['steady_seconds'] for x in z] for v,z in r.items()},
        throughput_ratio=med['baseline']/med['candidate'],paired_ratios=ratios,worker_cpu_medians=worker,
        signature=r['baseline'][0]['signatures_sha256'],points=r['baseline'][0]['points']))
report=dict(status='passed',elapsed_seconds=time.monotonic()-began,summary=summary,rows=rows,
    limitations=['Cloud CPU emulation, not Ada/Boole GPU performance.','Local filesystem durable journal/checkpoint, not NFS/shared ledger.',
      'Short bounded selected windows; shared cloud scheduling can vary.','Actual immutable task/certificate/packet/hit identities match each pair.',
      'Fresh preparation on every trial. Includes native CPU, exact decode, first-chunk GMP audit and durable commit. Startup/shutdown reported separately.'])
(ROOT/'benchmark-results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(summary,indent=2))
