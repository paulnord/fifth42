#!/bin/sh
# Offline reproduction in a NEW scratch directory with an existing pinned Python.
set -eu
if [ "$#" -lt 2 ] || [ "$#" -gt 3 ]; then
  echo "Usage: sh reproduce.sh NEW_SCRATCH_DIRECTORY PINNED_PYTHON [--benchmark]" >&2
  exit 2
fi
pkg=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
out=$1
python=$2
case "$out" in /*) ;; *) echo "Scratch directory must be absolute" >&2; exit 2;; esac
case "$python" in /*) ;; *) echo "Python path must be absolute" >&2; exit 2;; esac
if [ -e "$out" ]; then echo "Refusing existing output directory" >&2; exit 2; fi
if [ "$#" -eq 3 ] && [ "$3" != --benchmark ]; then echo "Unknown option" >&2; exit 2; fi
cd "$pkg"
sha256sum -c PACKAGE_SHA256SUMS > /dev/null
"$python" -c 'import sys,importlib.metadata as m; pins={"sympy":"1.14.0","fpylll":"0.6.4","cysignals":"1.12.5","numpy":"2.3.5","gmpy2":"2.2.2"}; assert sys.version_info[:2]==(3,12); assert all(m.version(k)==v for k,v in pins.items())'
mkdir "$out"
cp -R "$pkg/baseline" "$out/baseline"
cp -R "$pkg/baseline" "$out/candidate"
cp "$pkg/test_root_reuse.py" "$pkg/run_probe.py" "$pkg/benchmark_pairs.py" "$pkg/reuse-exact-lower-root.patch" "$out/"
patch -s -p1 -d "$out/candidate" < "$pkg/reuse-exact-lower-root.patch"
# This historical manifest is explicitly not the modified candidate's identity.
mv "$out/candidate/release-manifest.json" "$out/candidate/UPSTREAM_RELEASE_MANIFEST_REFERENCE.json"
mkdir -p "$out/native/bin"
cp -R "$out/baseline/native-baseline/src" "$out/baseline/native-baseline/vendor" "$out/native/"
cxx=${CXX:-g++}
"$cxx" -std=c++17 -O3 -Wall -Wextra -Werror -pthread "$out/native/src/scaling_cpu.cpp" -o "$out/native/bin/scaling_cpu"
"$cxx" -std=c++17 -O1 -g -fsanitize=undefined -fno-sanitize-recover=all -pthread "$out/native/src/scaling_cpu.cpp" -o "$out/native/bin/scaling_cpu_ubsan"
"$cxx" -std=c++17 -O3 -Wall -Wextra -Werror "$out/baseline/independent/gmp_reference.cpp" -lgmpxx -lgmp -o "$out/native/bin/gmp_reference"
make -C "$out/candidate/source/lattice_gpu" -f scaling.mk -j1 scaling-host > "$out/native-build.log" 2>&1
"$python" "$out/test_root_reuse.py" > "$out/unit-tests.log" 2>&1
ROOT_REUSE_VARIANT=baseline "$python" "$out/run_probe.py" validate --output "$out/validation-baseline.json"
ROOT_REUSE_VARIANT=candidate "$python" "$out/run_probe.py" validate --output "$out/validation-candidate.json"
"$python" - "$out" <<'PY'
import json,sys
from pathlib import Path
p=Path(sys.argv[1]);a=json.load(open(p/'validation-baseline.json'));b=json.load(open(p/'validation-candidate.json'))
assert a['cases']==b['cases'],'Baseline/candidate exact validation mismatch'
print('All 16 baseline/candidate native validation cases match.')
PY
(cd "$out/candidate/source/lattice_gpu" && SCALING_LATTICE_SOURCE="$out/candidate/source/lattice_prototype" "$python" -m unittest discover -s tests -v) > "$out/upstream-gpu-tests.log" 2>&1
(cd "$out/candidate/source/lattice_prototype" && "$python" -m unittest -v test_lattice5 test_backends test_modular_filters) > "$out/upstream-lattice-tests.log" 2>&1
(cd "$out/candidate/source/lattice_prototype/compiled_experiment" && "$python" -m unittest -v test_mpq) > "$out/upstream-mpq-tests.log" 2>&1
if [ "$#" -eq 3 ]; then "$python" "$out/benchmark_pairs.py" > "$out/benchmark-console.log" 2>&1; fi
echo "Passed. Results: $out"
echo "No production jobs, shared ledgers, services, CUDA, or remote repositories were modified."
